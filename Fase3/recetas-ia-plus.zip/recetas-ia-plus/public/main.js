// main.js
const $  = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

let API_BASE = "../api/";
{
  const parts = location.pathname.split("/").filter(Boolean);
  const idx = parts.lastIndexOf("public");
  if (idx >= 0) API_BASE = "/" + parts.slice(0, idx).join("/") + "/api/";
}

// =================== Helpers comunes ===================

async function safeJson(res) {
  const txt = await res.text();
  try {
    return JSON.parse(txt);
  } catch {
    return { error: "invalid_json", raw: txt };
  }
}

async function api(url, opts = {}) {
  try {
    const r = await fetch(API_BASE + url, { cache: "no-store", ...opts });
    const body = await safeJson(r);
    if (!r.ok) return { error: `HTTP ${r.status}`, ...body, http: r.status };
    return body;
  } catch (e) {
    return { error: e.message || "network_error" };
  }
}

function clearIngredients() {
  const input = $("#ingredients");
  if (input) {
    input.value = "";
    input.focus();
  }
}

function info(node, text) {
  if (node) node.innerHTML = `<p class="tag">${text}</p>`;
}

// estado de usuario en el front
let CURRENT_USER = null;

/* ======================== Recetas generadas ======================== */

let _last = [];
let _favorites = [];      // favoritos desde la BD
let _historyRecipes = []; // recetas (parseadas) desde historial


function card(r, i) {
  const imgBlock = r.imagen_url
    ? `<div class="recipe-img-wrap">
         <img src="${r.imagen_url}" alt="${r.titulo || "Receta"}">
       </div>`
    : `<div class="recipe-img-wrap skeleton" data-img="${i}"></div>`;

  // Ingredientes con cantidades
  let ingredientesHtml = "";
  if (Array.isArray(r.ingredientes_detalle) && r.ingredientes_detalle.length) {
    ingredientesHtml = `
      <div class="recipe-ingredients">
        <h4>Ingredientes</h4>
        <ul>
          ${r.ingredientes_detalle.map(it => {
            const label =
              it.amount_display ||
              `${it.amount ?? ""} ${it.unit ?? ""}`.trim();
            return `<li>${label} · ${it.name}</li>`;
          }).join("")}
        </ul>
      </div>
    `;
  } else if (Array.isArray(r.ingredientes_usados) && r.ingredientes_usados.length) {
    ingredientesHtml = `
      <div class="recipe-ingredients">
        <h4>Ingredientes</h4>
        <ul>
          ${r.ingredientes_usados.map(n => `<li>${n}</li>`).join("")}
        </ul>
      </div>
    `;
  }

  // Nutrición
  let nutriHtml = "";
  if (r.nutricion) {
    const n = r.nutricion;
    nutriHtml = `
      <div class="recipe-nutri muted">
        <span class="pill">🔥 ${n.kcal ?? "–"} kcal</span>
        <span class="pill">🥩 ${n.proteina_g ?? "–"} g proteína</span>
        <span class="pill">🍞 ${n.carbohidratos_g ?? "–"} g carbos</span>
        <span class="pill">🧈 ${n.grasas_g ?? "–"} g grasas</span>
      </div>
    `;
  }

  return `
    <div class="recipe">
      ${imgBlock}
      <h3>${r.titulo || "Receta"}</h3>
      <div class="recipe-meta">
        <span class="tag">⏱ ${r.tiempo_min ?? "-"} min</span>
        <span class="tag">🍽 ${r.porciones ?? "-"} porciones</span>
      </div>
      ${nutriHtml}
      ${ingredientesHtml}
      ${(r.ingredientes_usados && r.ingredientes_usados.length)
        ? `<p class="recipe-uses"><b>Usa:</b> ${r.ingredientes_usados.join(", ")}</p>` : ""}
      <ol>${(r.pasos || []).map(p => `<li>${p}</li>`).join("")}</ol>
      <div class="recipe-actions">
        <button class="btn outline" data-fav="${i}">⭐ Guardar favorito</button>
        <button class="btn outline" data-cook-mode="${i}">👀 Modo cocina</button>
        <button class="btn" data-cook="${i}">🍳 Cocinar y descontar</button>
      </div>
    </div>`;
}

async function ensureRecipeImages() {
  const placeholders = document.querySelectorAll(".recipe-img-wrap.skeleton[data-img]");
  for (const ph of placeholders) {
    const idx = parseInt(ph.getAttribute("data-img"), 10);
    const r = _last[idx];
    if (!r) continue;
    if (r.imagen_url) continue;

    try {
      const d = await api("recipe_image.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: r.titulo,
          description: (r.ingredientes_usados || []).join(", ")
        })
      });

      if (d && d.ok && d.url) {
        r.imagen_url = d.url;
        ph.classList.remove("skeleton");
        ph.innerHTML = `<img src="${d.url}" alt="${r.titulo}">`;
      } else {
        console.warn("No se pudo generar imagen para", r.titulo, d);
      }
    } catch (e) {
      console.error("Error generando imagen", e);
    }
  }
}
/* ======================== Acciones de tarjetas de receta ======================== */

function wireRecipeCards(rootSelector = "#results") {
  const root = document.querySelector(rootSelector) || document;
  
  // ⭐ Favoritos
  root.querySelectorAll("[data-fav]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      const button = e.currentTarget;

      if (!CURRENT_USER) {
        openLoginModal();
        alert("Para guardar favoritos necesitas iniciar sesión.");
        return;
      }

      const idx = parseInt(button.getAttribute("data-fav"), 10);
      const rec = _last[idx];
      if (!rec) return;

      button.disabled   = true;
      button.textContent = "Guardando...";

      const r = await api("favorite.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "add",
          title: rec.titulo || "Receta",
          data:  rec
        })
      });

      if (r.error || r.ok === false) {
        alert("No se pudo guardar favorito: " + (r.error || "error"));
        button.disabled   = false;
        button.textContent = "⭐ Guardar favorito";
        return;
      }

      button.textContent = "💖 Guardado";
      button.classList.add("saved");
      button.disabled = true;

      loadFavorites();
    });
  });

  // 🍳 Cocinar y descontar
  root.querySelectorAll("[data-cook]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      const i   = parseInt(e.currentTarget.getAttribute("data-cook"), 10);
      const rec = _last[i];
      if (!rec) return;

      let items = [];

      if (Array.isArray(rec.ingredientes_detalle) && rec.ingredientes_detalle.length) {
        items = rec.ingredientes_detalle.map(it => ({
          name:  it.name,
          amount: Number(it.amount) || 0,
          unit:  it.unit || ""
        }));
      } else if (Array.isArray(rec.ingredientes_usados) && rec.ingredientes_usados.length) {
        items = rec.ingredientes_usados.slice();
      }

      if (!items.length) {
        alert("No hay ingredientes para descontar.");
        return;
      }

      const r = await api("consume_pantry.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items })
      });

      if (r.faltantes && r.faltantes.length) {
        const msg = r.faltantes.map(f => `• ${f}`).join("\n");
        alert("No tienes suficiente de algunos ingredientes:\n\n" + msg);
        return;
      }

      if (r.error || r.ok === false) {
        alert("No se pudo descontar: " + (r.error || "error"));
        return;
      }

      alert("¡Receta cocinada! Descontado de la despensa.");
      loadPantryBox();
      loadPantryTextareaFromBox();
    });
  });

  // 👀 Modo cocina
  root.querySelectorAll("[data-cook-mode]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const i = parseInt(e.currentTarget.getAttribute("data-cook-mode"), 10);
      openCookModal(i);
    });
  });
}


/* ============ Acciones de las tarjetas de receta (favorito, cocinar, modo cocina) ============ */

/* ======================== Acciones de tarjetas de receta ======================== */

function wireRecipeCards(rootSelector = "#results") {
  const root = document.querySelector(rootSelector) || document;
  
  // ⭐ Favoritos
  root.querySelectorAll("[data-fav]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      const button = e.currentTarget;

      if (!CURRENT_USER) {
        openLoginModal();
        alert("Para guardar favoritos necesitas iniciar sesión.");
        return;
      }

      const idx = parseInt(button.getAttribute("data-fav"), 10);
      const rec = _last[idx];
      if (!rec) return;

      button.disabled   = true;
      button.textContent = "Guardando...";

      const r = await api("favorite.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "add",
          title: rec.titulo || "Receta",
          data:  rec
        })
      });

      if (r.error || r.ok === false) {
        alert("No se pudo guardar favorito: " + (r.error || "error"));
        button.disabled   = false;
        button.textContent = "⭐ Guardar favorito";
        return;
      }

      button.textContent = "💖 Guardado";
      button.classList.add("saved");
      button.disabled = true;

      loadFavorites();
    });
  });

  // 🍳 Cocinar y descontar
  root.querySelectorAll("[data-cook]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      const i   = parseInt(e.currentTarget.getAttribute("data-cook"), 10);
      const rec = _last[i];
      if (!rec) return;

      let items = [];

      if (Array.isArray(rec.ingredientes_detalle) && rec.ingredientes_detalle.length) {
        items = rec.ingredientes_detalle.map(it => ({
          name:  it.name,
          amount: Number(it.amount) || 0,
          unit:  it.unit || ""
        }));
      } else if (Array.isArray(rec.ingredientes_usados) && rec.ingredientes_usados.length) {
        items = rec.ingredientes_usados.slice();
      }

      if (!items.length) {
        alert("No hay ingredientes para descontar.");
        return;
      }

      const r = await api("consume_pantry.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items })
      });

      if (r.faltantes && r.faltantes.length) {
        const msg = r.faltantes.map(f => `• ${f}`).join("\n");
        alert("No tienes suficiente de algunos ingredientes:\n\n" + msg);
        return;
      }

      if (r.error || r.ok === false) {
        alert("No se pudo descontar: " + (r.error || "error"));
        return;
      }

      alert("¡Receta cocinada! Descontado de la despensa.");
      loadPantryBox();
      loadPantryTextareaFromBox();
    });
  });

  // 👀 Modo cocina
  root.querySelectorAll("[data-cook-mode]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const i = parseInt(e.currentTarget.getAttribute("data-cook-mode"), 10);
      openCookModal(i);
    });
  });
}


/* ======================== Despensa ======================== */

let _pantry = [];

/** Render de la tabla de despensa */
function renderPantry(filter = "") {
  const body = $("#pantryBody");
  if (!body) return;

  const f = filter.trim().toLowerCase();

  const STEP = { g: 100, ml: 100, und: 1 };
  const prettyUnit = (u) =>
    (u === "g" ? "g" : u === "ml" ? "ml" : u === "und" ? "und" : (u || ""));

  const rows = _pantry
    .filter(it => !f || (it.name || "").toLowerCase().includes(f))
    .map(it => {
      const step = STEP[it.unit] ?? 1;
      const label = it.display || `${it.amount} ${prettyUnit(it.unit)}`;
      const plusLabel = `+${step}`;
      const minusLabel = `−${step}`;
      return `
        <tr>
          <td>${it.name}</td>
          <td><span class="badge-qty">${label}</span></td>
          <td>
            <button class="btn xs" data-op="inc" data-name="${it.name}" data-unit="${it.unit}" data-step="${step}">${plusLabel}</button>
            <button class="btn xs outline" data-op="dec" data-name="${it.name}" data-unit="${it.unit}" data-step="${step}">${minusLabel}</button>
            <button class="btn xs outline" data-op="del" data-name="${it.name}" data-unit="${it.unit}">🗑</button>
          </td>
        </tr>`;
    })
    .join("");

  body.innerHTML = rows || `<tr><td colspan="3" class="muted">Sin ingredientes en la despensa</td></tr>`;

  body.querySelectorAll("[data-op]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const el   = e.currentTarget;
      const op   = el.getAttribute("data-op");
      const name = el.getAttribute("data-name");
      const unit = el.getAttribute("data-unit") || "und";
      const step = parseFloat(el.getAttribute("data-step") || "1");

      const payload = (op === "del")
        ? { op: "del", name, unit }
        : { op: "delta", name, unit, delta: op === "inc" ? step : -step };

      const d = await api("update_pantry.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (d.error || d.ok === false) {
        alert("Error: " + (d.error || "operación"));
        return;
      }
      loadPantryBox();
    });
  });
}

async function loadPantryBox() {
  const d = await api("list_pantry.php");
  _pantry = Array.isArray(d.items) ? d.items : [];
  renderPantry($("#pantrySearch")?.value || "");
}

/* ======================== Recetas destacadas (cards fijas) ======================== */

function attachFeaturedRecipes() {
  document.querySelectorAll(".mini-receta").forEach(cardEl => {
    const detail = cardEl.querySelector(".mini-detail");
    if (!detail) return;

    cardEl.addEventListener("click", () => {
      if (!detail.dataset.loaded) {
        const titulo = cardEl.dataset.title || "Receta";
        const tiempo = cardEl.dataset.tiempo || "";
        const porciones = cardEl.dataset.porciones || "";
        const ingredientes = (cardEl.dataset.ingredientes || "")
          .split(",")
          .map(s => s.trim())
          .filter(Boolean);
        const pasos = (cardEl.dataset.steps || "")
          .split("|")
          .map(s => s.trim())
          .filter(Boolean);

        detail.innerHTML = `
          <span class="pill">
            ${tiempo ? `${tiempo} min` : ""}${tiempo && porciones ? " · " : ""}${porciones ? `${porciones} porciones` : ""}
          </span>
          <h4>${titulo}</h4>
          <h4>Ingredientes</h4>
          <ul>
            ${ingredientes.map(i => `<li>${i}</li>`).join("")}
          </ul>
          <h4>Pasos</h4>
          <ol>
            ${pasos.map(p => `<li>${p}</li>`).join("")}
          </ol>
        `;
        detail.dataset.loaded = "1";
      }

      cardEl.classList.toggle("open");
    });
  });
}

// Inicializar destacados
attachFeaturedRecipes();

/* ======================== Guardar despensa (SIN IA) ======================== */

async function savePantry() {
  const raw = ($("#ingredients")?.value || "").trim();
  if (!raw) {
    alert("Escribe ingredientes o pega tu lista primero");
    return;
  }

  const items = raw
    .split(/[,;\n]/)
    .map(s => s.trim())
    .filter(Boolean);

  if (!items.length) {
    alert("No se detectaron ingredientes");
    return;
  }

  const d = await api("save_pantry.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items })
  });

  if (d.error || d.ok === false) {
    alert("Error al guardar: " + (d.error || d.message || "error"));
    console.error("save_pantry.php →", d);
    return;
  }

  alert(`Guardado (${d.added ?? d.count ?? items.length})`);
  clearIngredients();
  loadPantryBox();
}

/* ======================== Rellenar textarea desde despensa ======================== */

async function loadPantryTextareaFromBox() {
  const d = await api("list_pantry.php");
  if (d.error) {
    alert("Error al cargar despensa: " + d.error);
    return;
  }

  const ta = $("#ingredients");
  if (!ta) return;

  const out = (d.items || []).map(i => {
    const amount = Number(i.amount);
    const unit   = i.unit;

    if (unit === "g") {
      if (amount >= 1000) {
        return `${(amount / 1000).toFixed(1).replace(/\.0$/, "")} kg ${i.name}`;
      }
      return `${amount} g ${i.name}`;
    }

    if (unit === "ml") {
      if (amount >= 1000) {
        return `${(amount / 1000).toFixed(1).replace(/\.0$/, "")} L ${i.name}`;
      }
      return `${amount} ml ${i.name}`;
    }

    return `${amount} und ${i.name}`;
  });

  ta.value = out.join(", ");
}

/* ======================== Modo cocina (paso a paso) ======================== */
let cookIndex = null;
let cookStepIndex = 0;

const cookModal       = document.getElementById("cook-modal");
const cookTitleEl     = document.getElementById("cook-title");
const cookUsesEl      = document.getElementById("cook-uses");
const cookStepsOl     = document.getElementById("cook-steps");
const cookPrevBtn     = document.getElementById("cook-prev");
const cookNextBtn     = document.getElementById("cook-next");
const cookProgressEl  = document.getElementById("cook-progress");
const cookCloseBtn    = document.getElementById("cook-close");
const cookCloseBottom = document.getElementById("cook-close-bottom");

function openCookModal(index) {
  const rec = _last[index];
  if (!rec || !cookModal) return;

  cookIndex     = index;
  cookStepIndex = 0;

  const steps = rec.pasos || [];
  const uses  = rec.ingredientes_usados || [];

  if (cookTitleEl) {
    cookTitleEl.textContent = rec.titulo || "Modo cocina";
  }

  if (cookUsesEl) {
    cookUsesEl.textContent = uses.length
      ? "Usa: " + uses.join(", ")
      : "";
  }

  if (cookStepsOl) {
    cookStepsOl.innerHTML = steps.map((p, idx) =>
      `<li class="${idx === 0 ? "active" : ""}">${p}</li>`
    ).join("");
  }

  updateCookProgress();

  cookModal.classList.add("open");
  cookModal.setAttribute("aria-hidden", "false");
}

function closeCookModal() {
  if (!cookModal) return;
  cookModal.classList.remove("open");
  cookModal.setAttribute("aria-hidden", "true");
  cookIndex     = null;
  cookStepIndex = 0;
}

function updateCookProgress() {
  if (cookIndex === null) return;
  const rec = _last[cookIndex];
  if (!rec) return;

  const steps = rec.pasos || [];
  const total = steps.length || 1;

  if (cookStepsOl) {
    const items = cookStepsOl.querySelectorAll("li");
    items.forEach((li, idx) => {
      li.classList.toggle("active", idx === cookStepIndex);
    });
  }

  if (cookProgressEl) {
    cookProgressEl.textContent = `Paso ${cookStepIndex + 1} de ${total}`;
  }

  if (cookPrevBtn) cookPrevBtn.disabled = (cookStepIndex === 0);
  if (cookNextBtn) cookNextBtn.disabled = (cookStepIndex >= total - 1);
}

// listeners del modal de cocina
cookPrevBtn?.addEventListener("click", () => {
  if (cookIndex === null) return;
  if (cookStepIndex > 0) {
    cookStepIndex--;
    updateCookProgress();
  }
});

cookNextBtn?.addEventListener("click", () => {
  if (cookIndex === null) return;
  const rec   = _last[cookIndex];
  const steps = rec?.pasos || [];
  if (cookStepIndex < steps.length - 1) {
    cookStepIndex++;
    updateCookProgress();
  }
});

cookCloseBtn?.addEventListener("click", closeCookModal);
cookCloseBottom?.addEventListener("click", closeCookModal);
cookModal?.addEventListener("click", (e) => {
  if (e.target === cookModal) closeCookModal();
});

/* ======================== Sugerir recetas ======================== */

async function suggest() {
  const $res = $("#results");
  info($res, "Generando...");

  const diet = $("#diet")?.value || "ninguna";

  const d = await api("suggest_recipes.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ diet })
  });

  if (d.error) {
    info($res, "Error: " + d.error);
    return;
  }

  _last = Array.isArray(d.recetas) ? d.recetas : [];
  if (!_last.length) {
    info($res, "Sin resultados");
    return;
  }

  $res.innerHTML = _last.map((x, i) => card(x, i)).join("");

  await ensureRecipeImages();
  wireRecipeCards("#results");

  clearIngredients();
}



/* ======================== Favoritos / Historial / Lista ======================== */

async function loadFavorites() {
  const d = await api("favorite.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "list" })
  });

  const box = $("#favorites");
  if (!box) return;

  if (d.error) {
    box.innerHTML = "<p class='muted'>Error al cargar favoritos</p>";
    _favorites = [];
    return;
  }

  _favorites = Array.isArray(d.items) ? d.items : [];

  if (!_favorites.length) {
    box.innerHTML = "<p class='muted'>Sin favoritos</p>";
    return;
  }

  box.innerHTML = _favorites.map((it, idx) => {
    const t = it.created_at ? new Date(it.created_at).toLocaleString() : "";
    return `
      <button class="fav-item" data-idx="${idx}">
        <div class="fav-title">${it.recipe_title || "Receta"}</div>
        <div class="fav-meta muted">${t}</div>
      </button>
    `;
  }).join("");

  // click -> mostrar receta completa en la sección de sugerencias
  box.querySelectorAll(".fav-item").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.getAttribute("data-idx"), 10);
      const row = _favorites[idx];
      if (!row) return;

      let receta = null;

      if (typeof row.recipe_json === "string") {
        try { receta = JSON.parse(row.recipe_json); } catch (e) {
          console.error("Error parseando recipe_json", e, row.recipe_json);
        }
      } else if (row.recipe_json && typeof row.recipe_json === "object") {
        receta = row.recipe_json;
      } else if (row.data && typeof row.data === "object") {
        receta = row.data;
      }

      if (!receta) {
        alert("No se pudo leer la receta guardada.");
        return;
      }

      const res = $("#results");
      if (!res) return;

      _last = [receta];                 // la tratamos como "última receta"
      res.innerHTML = card(receta, 0);  // pintamos un solo card
      ensureRecipeImages();
      wireRecipeCards("#results");      // vuelve a enganchar botones

      document.querySelector("#section-recetas")
        ?.scrollIntoView({ behavior: "smooth" });
    });
  });
}



async function loadHistory() {
  const d = await api("list_history.php");
  const el = $("#history");
  if (!el) return;

  if (d.error) {
    el.innerHTML = "<p class='muted'>Error al cargar historial</p>";
    _historyRecipes = [];
    return;
  }

  const items = d.items || [];
  _historyRecipes = []; // reseteamos buffer de recetas

  if (!items.length) {
    el.innerHTML = "<p class='muted'>Sin historial</p>";
    return;
  }

  el.innerHTML = items.map(it => {
    const title = it.recipe_title || it.title || "Receta";
    const t = it.created_at ? new Date(it.created_at).toLocaleString() : "";
    // mientras pintamos, intentamos parsear la receta
    let receta = null;

    if (typeof it.recipe_json === "string") {
      try { receta = JSON.parse(it.recipe_json); } catch (e) {
        console.warn("recipe_json inválido en historial", e, it.recipe_json);
      }
    } else if (it.recipe_json && typeof it.recipe_json === "object") {
      receta = it.recipe_json;
    }

    if (receta) _historyRecipes.push(receta);

      return `
      <div class="history-item">
        <div class="history-title">${title}</div>
        ${t ? `<div class="history-meta">${t}</div>` : ""}
      </div>
    `;

  }).join("");
}


//* ======================== Dieta semanal usando despensa ======================== */

// Color dinámico según la info nutricional
function colorFromNutrition(n = {}) {
  const kcal  = n.kcal ?? 0;
  const prot  = n.proteina_g ?? 0;
  const carb  = n.carbohidratos_g ?? 0;
  const grasa = n.grasas_g ?? 0;

  // Generamos un tono en base a los nutrientes
  const hue   = (prot * 3 + carb * 1.5 + grasa * 2) % 360;
  const sat   = 45 + (kcal % 20);             // saturación moderada
  const light = 24 + ((prot + grasa) % 12);   // un poco más claro para que se vea

  return `hsl(${hue}, ${sat}%, ${light}%)`;
}

async function generateWeeklyPlanFromPantry() {
  const cont = document.getElementById("weekly-plan");
  if (!cont) return;

  cont.innerHTML = "<p class='muted'>Armando un plan semanal con tu despensa...</p>";

  const diet = $("#diet")?.value || "ninguna";

  // volvemos a pedir recetas a la IA – usa la despensa guardada en backend
  const d = await api("suggest_recipes.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ diet })
  });

  if (d.error || !Array.isArray(d.recetas) || !d.recetas.length) {
    cont.innerHTML = "<p class='muted'>No se pudieron generar recetas con tu despensa actual.</p>";
    return;
  }

  const recetas = d.recetas;
  const days    = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"];

  const cards = days.map((day, idx) => {
  const rec = recetas[idx % recetas.length];
  const n   = rec.nutricion || {};

  const kcal  = n.kcal ?? "–";
  const prot  = n.proteina_g ?? "–";
  const carb  = n.carbohidratos_g ?? "–";
  const grasa = n.grasas_g ?? "–";

  const usados = Array.isArray(rec.ingredientes_usados)
    ? rec.ingredientes_usados.join(", ")
    : "";

  const paso1 = rec.pasos?.[0] ?? "Sin pasos disponibles.";

  // color de fondo dinámico SOLO si no hay imagen
  const bgStyle = rec.imagen_url
    ? ""
    : `background:${colorFromNutrition(n)}; box-shadow:0 0 0 1px rgba(255,255,255,0.06) inset;`;

  return `
  <div class="week-day-full">
    <div class="week-header">
      <h3>${day}</h3>
    </div>
    <div class="week-content">
      <div class="week-img" style="${bgStyle}">
        ${rec.imagen_url
          ? `<img src="${rec.imagen_url}" alt="${rec.titulo}">`
          : `<div class="week-img-placeholder">🍽️</div>`}
      </div>
      <div class="week-info">
        <h4>${rec.titulo || "Receta"}</h4>
        <p class="muted small">
          🔥 ${kcal} kcal · 🥩 ${prot} g prot · 🍞 ${carb} g carb · 🧈 ${grasa} g grasa
        </p>
        ${usados ? `<p class="muted small">🧺 Ingredientes utilizados: ${usados}</p>` : ""}
        <p class="muted small">👣 Primer paso: ${paso1}</p>
        <button class="btn xs outline" onclick="openCookModal(${idx % recetas.length})">
          👀 Ver modo cocina
        </button>
      </div>
    </div>
  </div>
`;

}).join("");


  cont.innerHTML = `
    <div class="week-grid">
      ${cards}
    </div>
    <p class="muted" style="margin-top:8px">
      Plan generado con las recetas que la IA puede crear usando tu despensa guardada.
    </p>
  `;
}


async function genList() {
  if (!_last.length) {
    alert("Genera recetas primero");
    return;
  }
  const d = await api("shopping_list.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ recipes: _last })
  });
  if (d.error) {
    alert("Error al generar lista: " + d.error);
    return;
  }
  $("#shopping").innerHTML = (d.items || []).map(i => `<li>${i.qty} × ${i.name}</li>`).join("");
}



/* ======================== Subir boleta ======================== */

async function uploadReceipt() {
  const input = document.getElementById("receiptFile");
  const hint  = document.getElementById("uploadHint");
  const f = input?.files?.[0];
  if (!f) { alert("Selecciona una imagen o PDF"); return; }

  hint.textContent = "Procesando boleta...";

  async function canvasToJpegFile(canvas, name = "page1.jpg", quality = 0.92) {
    return new Promise(resolve => {
      canvas.toBlob(
        blob => resolve(new File([blob], name, { type: "image/jpeg" })),
        "image/jpeg",
        quality
      );
    });
  }

  let fileToSend = f;
  if (f.type === "application/pdf") {
    try {
      hint.textContent = "Convirtiendo PDF a imagen…";
      const pdfjsLib = window["pdfjsLib"] || (await import("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.min.mjs"));
      if (pdfjsLib.GlobalWorkerOptions) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.worker.min.js";
      }

      const buf  = await f.arrayBuffer();
      const pdf  = await pdfjsLib.getDocument({ data: buf }).promise;
      const page = await pdf.getPage(1);

      const viewport = page.getViewport({ scale: 2.0 });
      const canvas   = document.createElement("canvas");
      const ctx      = canvas.getContext("2d");
      canvas.width   = viewport.width;
      canvas.height  = viewport.height;

      await page.render({ canvasContext: ctx, viewport }).promise;

      const base = (f.name.replace(/\.pdf$/i, "") || "page1") + ".jpg";
      fileToSend = await canvasToJpegFile(canvas, base, 0.92);
    } catch (e) {
      console.error(e);
      hint.textContent = "No pude convertir el PDF. Intenta subir una foto (JPG/PNG/WEBP).";
      return;
    }
  }

  const fd = new FormData();
  fd.append("receipt", fileToSend);
  fd.append("file",    fileToSend);

  hint.textContent = "Enviando…";
  const res  = await fetch(API_BASE + "upload_receipt.php", { method: "POST", body: fd });
  const data = await safeJson(res);

  if (!res.ok || data.error || data.ok === false) {
    hint.textContent = data.message || data.error || `Error HTTP ${res.status}`;
    console.warn(data.raw || "");
    return;
  }

  const items = data.items || [];
if (!items.length) {
  hint.textContent = data.message || "No se detectaron ingredientes";
  return;
}

// Rellenar textarea con cantidad + unidad + nombre (solo visual)
const ta = document.getElementById("ingredients");
if (ta) ta.value = items.map(i => {
  const qty  = i.qty ?? i.cantidad ?? 1;
  const unit = i.unit || i.unidad || "";
  const u    = unit ? ` ${unit}` : "";
  return `${qty}${u} ${i.name}`.trim();
}).join(", ");

// Enviar al backend los datos estructurados
const toSave = items.map(i => ({
  name: i.name,
  qty:  i.qty ?? i.cantidad ?? 1,
  unit: i.unit || i.unidad || ''
}));

const save = await api("save_pantry.php", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ items: toSave })
});

hint.textContent = (save && save.ok) ? `Guardado (${save.added ?? save.count ?? toSave.length})` : "Guardado parcial";
loadPantryBox();

}

/* ======================== Listeners básicos ======================== */

$("#btn-weekly-plan")?.addEventListener("click", generateWeeklyPlanFromPantry);
$("#saveBtn")?.addEventListener("click", savePantry);
$("#loadBtn")?.addEventListener("click", loadPantryTextareaFromBox);
$("#suggestBtn")?.addEventListener("click", suggest);
$("#genListBtn")?.addEventListener("click", genList);
$("#uploadBtn")?.addEventListener("click", uploadReceipt);
$("#pantrySearch")?.addEventListener("input", e => renderPantry(e.target.value));
$("#refreshPantryBtn")?.addEventListener("click", loadPantryBox);

/* ======================== Boot ======================== */

loadPantryTextareaFromBox();
loadFavorites();
loadHistory();
loadPantryBox();

/* ======================== Abastecimiento: mapa cercano ======================== */

function initSupplyMap() {
  const cont = document.getElementById("supply-map");
  const link = document.getElementById("btn-open-gmaps");
  if (!cont) return;

  cont.innerHTML = "<p class='muted'>Obteniendo ubicación...</p>";

  if (!navigator.geolocation) {
    console.warn("Geolocalización no soportada");
    const q = encodeURIComponent("supermercado cerca de mí");
    cont.innerHTML = `
      <iframe
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        src="https://www.google.com/maps/search/${q}/"
      ></iframe>
    `;
    if (link) {
      link.href = `https://www.google.com/maps/search/${q}/`;
    }
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const { latitude, longitude } = pos.coords;

      const q   = encodeURIComponent("supermercado");
      const src = `https://www.google.com/maps?q=${q}&ll=${latitude},${longitude}&z=15&output=embed`;

      cont.innerHTML = `
        <iframe
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          src="${src}"
        ></iframe>
      `;

      if (link) {
        link.href = `https://www.google.com/maps/search/${q}/@${latitude},${longitude},15z`;
      }
    },
    (err) => {
      console.error("Error geolocalización:", err);

      const q = encodeURIComponent("supermercado cerca de mí");
      cont.innerHTML = `
        <iframe
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          src="https://www.google.com/maps/search/${q}/"
        ></iframe>
      `;
      if (link) {
        link.href = `https://www.google.com/maps/search/${q}/`;
      }
    },
    {
      enableHighAccuracy: true,
      timeout: 10000
    }
  );
}

$("#btn-refresh-map")?.addEventListener("click", initSupplyMap);
initSupplyMap();

// ====================== Estado de usuario / sesión ======================
let currentUser = null; // ya no se usa, pero lo dejamos por compatibilidad

const authButton  = document.getElementById("auth-button");
const loginModal  = document.getElementById("login-modal");
const loginClose  = document.getElementById("login-close");
const loginName   = document.getElementById("login-name");
const loginEmail  = document.getElementById("login-email");
const loginPass   = document.getElementById("login-pass");
const errName     = document.getElementById("error-name");
const errEmail    = document.getElementById("error-email");
const errPass     = document.getElementById("error-pass");
const btnLogin    = document.getElementById("btn-login");
const btnRegister = document.getElementById("btn-register");

// --- abrir / cerrar modal ---
function openLoginModal() {
  if (!loginModal) return;
  loginModal.classList.add("open");
  loginModal.setAttribute("aria-hidden", "false");
}

function closeLoginModal() {
  if (!loginModal) return;
  loginModal.classList.remove("open");
  loginModal.setAttribute("aria-hidden", "true");
}

loginClose?.addEventListener("click", closeLoginModal);
loginModal?.addEventListener("click", (e) => {
  if (e.target === loginModal) closeLoginModal();
});

// Render del botón de la barra superior
function renderAuthButton() {
  if (!authButton) return;

  if (!CURRENT_USER) {
    authButton.classList.remove("logged");
    authButton.textContent = "Iniciar sesión";
    return;
  }

  const name    = CURRENT_USER.name || CURRENT_USER.email || "Usuario";
  const first   = name.split(" ")[0];
  const initial = first.charAt(0).toUpperCase();

  authButton.classList.add("logged");
  authButton.innerHTML = `
    <span class="user-pill">
      <span class="user-avatar">${initial}</span>
      <span class="user-name">${first}</span>
      <span class="user-logout">Salir</span>
    </span>
  `;
}

// --- click en el botón de la barra superior ---
//  - sin sesión  -> abre modal
//  - con sesión  -> cierra sesión directo (sin modal)
authButton?.addEventListener("click", async (e) => {
  e.preventDefault();

  if (!CURRENT_USER) {
    openLoginModal();
    return;
  }

  if (!confirm("¿Cerrar sesión?")) return;

  await api("auth_logout.php", { method: "POST" });
  CURRENT_USER = null;
  renderAuthButton();
  alert("Sesión cerrada.");
});

// --- helpers de validación ---
function clearAuthErrors() {
  if (errName)  errName.textContent  = "";
  if (errEmail) errEmail.textContent = "";
  if (errPass)  errPass.textContent  = "";
}

// action = "login" | "register"
function validateAuthForm(action) {
  clearAuthErrors();

  const name  = (loginName?.value || "").trim();
  const email = (loginEmail?.value || "").trim();
  const pass  = loginPass?.value || "";
  let ok = true;

  // El nombre solo es obligatorio al registrar
  if (action === "register") {
    if (!name) {
      if (errName) errName.textContent = "El nombre no puede estar vacío.";
      ok = false;
    }
  }

  if (!email) {
    if (errEmail) errEmail.textContent = "El correo no puede estar vacío.";
    ok = false;
  } else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    if (errEmail) errEmail.textContent = "Formato de correo no válido.";
    ok = false;
  }

  if (!pass) {
    if (errPass) errPass.textContent = "La contraseña no puede estar vacía.";
    ok = false;
  } else if (pass.length < 6) {
    if (errPass) errPass.textContent = "Mínimo 6 caracteres.";
    ok = false;
  }

  return ok;
}

async function doAuth(action) {
  if (!validateAuthForm(action)) return;

  const payload = {
    email: loginEmail.value.trim(),
    password: loginPass.value
  };

  if (action === "register") {
    payload.name = (loginName?.value || "").trim();
  }

  const endpoint = action === "register" ? "auth_register.php" : "auth_login.php";

  const res = await api(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  if (res.error || res.ok === false) {
    let msg = "Ocurrió un error.";
    switch (res.error) {
      case "invalid_json":    msg = "Error en el envío de datos."; break;
      case "missing_fields":  msg = "Completa correo y contraseña."; break;
      case "missing_name":    msg = "Debes ingresar tu nombre."; break;
      case "invalid_email":   msg = "Correo inválido."; break;
      case "weak_password":   msg = "La contraseña debe tener al menos 6 caracteres."; break;
      case "email_taken":     msg = "Ese correo ya está registrado."; break;
      case "bad_credentials": msg = "Correo o contraseña incorrectos."; break;
      default:                msg = res.error || msg;
    }
    alert("No se pudo autenticar: " + msg);
    return;
  }

  // éxito -> guardamos usuario, avatar, etc.
  CURRENT_USER = res.user || null;
  renderAuthButton();
  closeLoginModal();
  loginPass.value = "";

  alert(
    action === "register"
      ? "Cuenta creada y sesión iniciada 🎉"
      : "Sesión iniciada correctamente ✅"
  );
}

// clicks de los botones del modal
btnLogin.onclick = (e) => {
  e.preventDefault();
  doAuth("login");
};

btnRegister.onclick = (e) => {
  e.preventDefault();
  doAuth("register");
};


// --- al cargar la página, preguntamos si ya hay sesión ---
(async function bootstrapSession() {
  const r = await api("session.php");
  if (r && r.ok && r.user) {
    CURRENT_USER = r.user;
  } else {
    CURRENT_USER = null;
  }
  renderAuthButton();
})();

