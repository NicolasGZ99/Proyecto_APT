<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

// Normalizar unidades y llevar a base (g, ml, und)
function norm_unit($u) {
  $u = strtolower(trim((string)$u));
  $map = [
    'gr'=>'g','grs'=>'g','gramo'=>'g','gramos'=>'g',
    'kg'=>'kg','kilo'=>'kg','kilos'=>'kg','kilogramo'=>'kg','kilogramos'=>'kg',
    'lt'=>'l','lts'=>'l','litro'=>'l','litros'=>'l',
    'mililitro'=>'ml','mililitros'=>'ml',
    'unidad'=>'und','unid'=>'und','unidades'=>'und','unds'=>'und','u'=>'und'
  ];
  return $map[$u] ?? $u;
}

function to_base($qty, $unit) {
  $qty  = (float)$qty;
  $unit = norm_unit($unit);

  if ($unit === 'kg') return [$qty * 1000, 'g'];
  if ($unit === 'l')  return [$qty * 1000, 'ml'];
  if (in_array($unit, ['g','ml','und'], true)) {
    return [$qty, $unit];
  }
  // unidad desconocida → lo tratamos como unidad
  return [$qty, 'und'];
}

// Parsear item de receta: puede venir como string o array
function parse_recipe_item($it) {
  if (is_array($it)) {
    $name = trim($it['name'] ?? $it['ingrediente'] ?? $it['texto'] ?? '');
    $qty  = $it['amount'] ?? $it['qty'] ?? $it['cantidad'] ?? 0;
    $unit = $it['unit'] ?? $it['unidad'] ?? '';
    return [$name, (float)$qty, $unit];
  }

  $line = trim((string)$it);
  if ($line === '') return [null, 0, ''];

  // "100 g tomate"
  if (preg_match('/^([\d\.,]+)\s*([a-zA-ZñÑ]+)\s+(.+)$/u', $line, $m)) {
    $qty  = (float) str_replace(',', '.', $m[1]);
    $unit = $m[2];
    $name = trim($m[3]);
    return [$name, $qty, $unit];
  }
  // "3 tomate"
  if (preg_match('/^(\d+)\s+(.+)$/u', $line, $m)) {
    $qty  = (float) $m[1];
    $unit = 'und';
    $name = trim($m[2]);
    return [$name, $qty, $unit];
  }

  // Sólo nombre
  return [$line, 0, ''];
}

try {
  $db = db();

  $raw  = file_get_contents('php://input');
  $data = json_decode($raw, true);

  if (!$data && isset($_POST['items'])) {
    $data = ['items' => $_POST['items']];
  }

  if (!is_array($data) || !isset($data['items']) || !is_array($data['items'])) {
    respond(['error' => 'invalid_json', 'raw' => $raw], 400);
  }

  $items = $data['items'];
  if (!$items) {
    respond(['ok' => true, 'message' => 'Nada que descontar'], 200);
  }

  $db->beginTransaction();

  // Traemos TODOS los registros de ese nombre y decidimos cuál usar
  $selectAll = $db->prepare("
    SELECT id, name, amount, unit
    FROM pantry_item
    WHERE LOWER(name) = :name
    ORDER BY 
      CASE unit 
        WHEN 'g'  THEN 1 
        WHEN 'ml' THEN 2 
        WHEN 'und' THEN 3 
        ELSE 4 
      END
  ");

  $update = $db->prepare("
    UPDATE pantry_item
    SET amount = :newAmount
    WHERE id = :id
  ");

  $delete = $db->prepare("DELETE FROM pantry_item WHERE id = :id");

  $faltantes = [];

  foreach ($items as $it) {
    list($name, $qty, $unit) = parse_recipe_item($it);
    if (!$name) continue;

    $nameLower = mb_strtolower($name);

    $selectAll->execute([':name' => $nameLower]);
    $rows = $selectAll->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
      // No hay nada con ese nombre
      if ($qty > 0) {
        list($baseQty, $baseUnit) = to_base($qty, $unit);
        $faltantes[] = "$name (faltan " . $baseQty . " " . $baseUnit . ")";
      } else {
        $faltantes[] = "$name (no disponible)";
      }
      continue;
    }

    // Elegimos el primer registro (ya ordenado por prioridad de unidad)
    $row = $rows[0];
    $available   = (float) $row['amount'];
    $pantryUnit  = $row['unit'];

    // Cantidad que realmente vamos a usar y en QUÉ unidad
    $needed = 0;
    $neededUnit = $pantryUnit;

    if ($qty > 0 && $unit !== '') {
      list($qBase, $uBase) = to_base($qty, $unit);

      if ($uBase === $pantryUnit) {
        // Misma unidad → usar directamente la cantidad de la receta
        $needed     = $qBase;
        $neededUnit = $pantryUnit;
      } else {
        // Unidades no compatibles (ej: receta en g, despensa en und)
        // Usamos una regla por defecto en base a la unidad de la despensa
        if ($pantryUnit === 'g' || $pantryUnit === 'ml') {
          $needed = 100;        // 100 g / 100 ml por receta
        } else {
          $needed = 1;          // 1 unidad
        }
      }
    } else {
      // La receta no trae cantidad → regla por defecto
      if ($pantryUnit === 'g' || $pantryUnit === 'ml') {
        $needed = 100;
      } else {
        $needed = 1;
      }
    }

    // Si no hay suficiente, registramos faltante
    if ($available < $needed) {
      $faltantes[] = "$name (faltan " . ($needed - $available) . " " . $neededUnit . ")";
      continue;
    }

    // Descontar
    $newAmount = $available - $needed;
    if ($newAmount <= 0) {
      $delete->execute([':id' => $row['id']]);
    } else {
      $update->execute([
        ':newAmount' => $newAmount,
        ':id'        => $row['id']
      ]);
    }
  }

  if (count($faltantes) > 0) {
    $db->rollBack();
    respond([
      'ok'        => false,
      'faltantes' => $faltantes
    ], 200);
  }

  $db->commit();
  respond(['ok' => true]);

} catch (Throwable $e) {
  if (isset($db) && $db && $db->inTransaction()) {
    $db->rollBack();
  }
  respond(['error' => $e->getMessage()], 500);
}
