<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

/* -------------------- Utilidades -------------------- */

// quita tildes y deja solo letras/números/espacios (para matching)
function slug($s) {
  $s = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s);
  $s = strtolower($s);
  $s = preg_replace('~[^a-z0-9\s]~',' ', $s);
  return preg_replace('~\s+~',' ', trim($s));
}

function normalize_unit($u) {
  $u = strtolower(trim($u));
  $map = [
    'gr' => 'g','grs'=>'g','gramo'=>'g','gramos'=>'g',
    'kgs'=>'kg','kilo'=>'kg','kilos'=>'kg','kilogramo'=>'kg','kilogramos'=>'kg',
    'lt'=>'l','lts'=>'l','litro'=>'l','litros'=>'l',
    'ml'=>'ml','mL'=>'ml','Ml'=>'ml','ML'=>'ml',
    'unidad'=>'und','unid'=>'und','unidades'=>'und','unds'=>'und','und'=>'und'
  ];
  return $map[$u] ?? $u;
}

// convierte a cantidad en base común para comparar (masa→gramos, volumen→ml)
function to_base($qty, $unit, &$baseUnitOut) {
  $unit = normalize_unit($unit);
  $baseUnitOut = $unit;
  if ($unit === 'kg') { $baseUnitOut = 'g'; return $qty * 1000; }
  if ($unit === 'g')  { $baseUnitOut = 'g'; return $qty; }
  if ($unit === 'l')  { $baseUnitOut = 'ml'; return $qty * 1000; }
  if ($unit === 'ml') { $baseUnitOut = 'ml'; return $qty; }
  // no convertible (und/paquete, etc.)
  return $qty;
}

// busca TODAS las cantidades+unidades en una línea
function parse_quantities_in_line($line) {
  $found = [];
  // soporta "1,496 KG", "125 GR", "500G", "0.460 KG", "3 X $2.390" (→ 3 und)
  if (preg_match_all('/([\d\.,]+)\s*(kg|g|gr|grs|l|ml)\b/iu', $line, $m, PREG_SET_ORDER)) {
    foreach ($m as $hit) {
      $num = floatval(str_replace(',', '.', $hit[1]));
      $unit = normalize_unit($hit[2]);
      $found[] = ['qty'=>$num, 'unit'=>$unit];
    }
  }
  // patrón “3 X …” → 3 und
  if (preg_match('/\b(\d+)\s*[x×]\b/i', $line, $m2)) {
    $found[] = ['qty'=>floatval($m2[1]), 'unit'=>'und'];
  }
  return $found;
}

// para una lista de líneas, retorna la cantidad "más grande" (normalizada)
function pick_best_quantity_from_lines(array $lines) {
  $best = null; $bestBase = null; $bestBaseVal = -1;
  foreach ($lines as $ln) {
    foreach (parse_quantities_in_line($ln) as $q) {
      $baseUnit = '';
      $baseVal  = to_base($q['qty'], $q['unit'], $baseUnit);
      // comparamos por base sólo cuando la base coincide (g con g, ml con ml).
      // si son 'und', tomamos el mayor número de unidades.
      $key = $baseUnit ?: $q['unit'];
      $cmp = $baseVal;
      if ($key !== ($bestBase ?? $key)) {
        // si cambia de tipo (g vs ml), preferimos MASA (g/kg) por sobre volumen si coexisten
        // prioridad: g > ml > und
        $rank = ['g'=>3,'ml'=>2,'und'=>1];
        $currRank = $rank[$key] ?? 0;
        $bestRank = $rank[$bestBase] ?? 0;
        if ($currRank <= $bestRank) continue;
      }
      if ($cmp > $bestBaseVal) {
        $best = $q; $bestBase = $key; $bestBaseVal = $cmp;
      }
    }
  }
  return $best; // ['qty'=>..., 'unit'=>... ] o null
}

/* -------------------- Limpieza de boleta -------------------- */

function sanitize_ticket_text(string $t): string {
  $t = str_replace(["\r"], "", $t);
  $lines = array_values(array_filter(array_map('trim', explode("\n", $t))));

  $ignore = '~\b('
    . 'DESPACHO|ENVIO|ENVÍO|DELIVERY|SERVICIO|PROPINA|COBERT|COBERTU|COBERTURA|'
    . 'SUB\s*TOTAL|SUBTOTAL|TOTAL|NETO|IVA|EXENTO|AFECTO|T\.?\s*CREDITO|CR[EÉ]DITO|DEBITO|D[EÉ]BITO|VUELTO|REDONDEO|'
    . 'TIMBRE|ELECTR[ÓO]NICO|FOLIO|DOCUMENTO|OP\b|NUMERO\s*OP|N[°º]\s*OP|SII|RUT|GIRO|'
    . 'CAJA|CAJERO|ATENDI[ÓO]|LOCAL|SUCURSAL|TIENDA|AV\.?|AVENIDA|COMUNA|CIUDAD|'
    . 'EFECTIVO|TARJETA|PAGO|REFERENCIA|AUTORIZACI[ÓO]N|'
    . 'HORA|FECHA|VENCIMIENTO|VENCE|'
    . 'RESUMEN|DETALLE|CANTIDAD|PRODUCTO|PRECIO|UNITARIO|DESCUENTO'
    . ')\\b~i';

  $out = [];
  foreach ($lines as $ln) {
    if ($ln === '') continue;
    if (preg_match('~^[\d\.\,\s]+$~', $ln)) continue;
    $digitsOnly = preg_replace('~\D~', '', $ln);
// Si es casi puro número largo, PERO no contiene unidades de peso/volumen, la ignoramos.
// Así NO eliminamos líneas tipo "1,496 KG X $1.590".
    if (
      preg_match('~^\d{8,}$~', $digitsOnly) &&
      !preg_match('/\b(kg|kgs|g|gr|grs|l|ml)\b/i', $ln)
    ) {
      continue;
    }

    if (preg_match($ignore, $ln)) continue;
    $out[] = $ln;
  }
  return trim(implode("\n", $out));
}

/* -------------------- Controlador -------------------- */

try {
  $OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: ($OPENAI_API_KEY ?? '');
  if (!$OPENAI_API_KEY) respond(['error' => 'Falta OPENAI_API_KEY'], 500);

  $input = json_decode(file_get_contents('php://input'), true);
  $text  = trim($input['text'] ?? '');
  if ($text === '') respond(['ok'=>false,'message'=>'Texto vacío']);

  $cleanText = sanitize_ticket_text($text);
  if ($cleanText === '') respond(['ok'=>false,'message'=>'No hay contenido útil tras limpiar la boleta.']);

  $payload = [
    'model' => 'gpt-4o-mini',
    'temperature' => 0.2,
    'response_format' => ['type'=>'json_object'],
    'messages' => [
      [
        'role'=>'system',
        'content'=>
"Eres un analizador de ingredientes para boletas y texto libre.
Debes extraer SOLO ítems comestibles (frutas, verduras, carnes, lácteos, abarrotes, etc.).
IGNORA absolutamente: despacho/envío/coberturas, totales, impuestos, pagos, folios, RUT, SII, timbre, cajero, direcciones y cualquier línea administrativa.

Cada ítem:
- nombre (singular, sin marcas si es posible)
- cantidad (número; usa coma o punto, lo convertirán)
- unidad (g, kg, ml, l, und/paquete/pote u otras; null si no aplica)

Si ves doble medida en una línea (p.ej. 300 GR y 1,496 KG), la cantidad real es la que representa el PESO TOTAL comprado (normalmente la mayor al normalizar)."
      ],
      [
        'role'=>'user',
        'content'=>"Texto (limpio):\n\n{$cleanText}\n\nDevuelve SOLO el JSON con { items:[{nombre,cantidad,unidad}], confianza }."
      ]
    ]
  ];

  // Llamada a OpenAI
  $ch = curl_init('https://api.openai.com/v1/chat/completions');
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json',
      'Authorization: Bearer ' . $OPENAI_API_KEY
    ],
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE)
  ]);
  $raw = curl_exec($ch);
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err  = curl_error($ch);
  curl_close($ch);

  if ($raw === false) respond(['error'=>'cURL error','detail'=>$err], 502);

  $resp = json_decode($raw, true);
  if (json_last_error() !== JSON_ERROR_NONE) respond(['http_code'=>$http, 'raw_response'=>$raw], 500);
  if (isset($resp['error'])) respond(['http_code'=>$http, 'openai_error'=>$resp['error']], 500);

  $content = $resp['choices'][0]['message']['content'] ?? '';
  $data = json_decode($content, true);
  if (json_last_error() !== JSON_ERROR_NONE) {
    $clean = trim(preg_replace(['~^```(?:json)?~i','~```$~'], '', $content));
    $data = json_decode($clean, true);
  }
  if (json_last_error() !== JSON_ERROR_NONE || empty($data['items']) || !is_array($data['items'])) {
    respond(['ok'=>false,'message'=>'No se detectaron ingredientes','content_raw'=>$content], 200);
  }

  // Stoplist duro para evitar falsos positivos (despacho, coberturas, etc.)
  $stop = ['despacho','envio','envío','cobertu','cobertura','servicio','propina'];
  $cleanLines = array_values(array_filter(array_map('trim', explode("\n", $cleanText))));

  $final = [];
  foreach ($data['items'] as $i) {
    $nombre = trim((string)($i['nombre'] ?? ''));
    if ($nombre === '') continue;

    $slugName = slug($nombre);
    $skip = false;
    foreach ($stop as $bad) { if (str_contains($slugName, $bad)) { $skip = true; break; } }
    if ($skip) continue;

    // cantidad/unidad de la IA
    $qty   = isset($i['cantidad']) ? floatval(str_replace(',', '.', (string)$i['cantidad'])) : 0;
    $unit  = normalize_unit((string)($i['unidad'] ?? ''));

    // Buscar líneas candidatas por nombre (palabras clave)
    $tokens = array_values(array_filter(explode(' ', $slugName), fn($w)=>strlen($w)>=3));
    $candidates = [];
    foreach ($cleanLines as $ln) {
      $sln = slug($ln);
      foreach ($tokens as $t) {
        if (str_contains($sln, $t)) { $candidates[] = $ln; break; }
      }
    }
    // Si encontramos cantidades en esas líneas, elegimos la mayor normalizada
    $best = pick_best_quantity_from_lines($candidates);
    if ($best) {
      $qty  = floatval($best['qty']);
      $unit = normalize_unit($best['unit']);
    }

    // Normalización de presentación
    $unit = normalize_unit($unit);
    $prettyQty = ($qty > 0)
      ? rtrim(rtrim(number_format($qty, 3, '.', ''), '0'), '.')
      : '';
    $parts = [];
    if ($prettyQty !== '') $parts[] = $prettyQty;
    if ($unit !== '' && $unit !== 'null') $parts[] = $unit;
    $parts[] = $nombre;
    $pretty = preg_replace('/\s+/', ' ', trim(implode(' ', $parts)));

    $final[] = ['name'=>$pretty, 'qty'=>1];
  }

  // deduplicar por nombre visible
  $seen = [];
  $final = array_values(array_filter($final, function($x) use (&$seen){
    $k = strtolower($x['name']);
    if (isset($seen[$k])) return false;
    $seen[$k] = true;
    return true;
  }));

  if (empty($final)) {
    respond(['ok'=>false,'message'=>'Tras filtrar ruido no quedaron ingredientes válidos.','depurado'=>$cleanText], 200);
  }

  respond(['ok'=>true, 'items'=>$final, 'resultado'=>$data, 'depurado'=>$cleanText], 200);

} catch (Throwable $e) {
  respond(['error'=>'exception','detail'=>$e->getMessage()], 500);
}
