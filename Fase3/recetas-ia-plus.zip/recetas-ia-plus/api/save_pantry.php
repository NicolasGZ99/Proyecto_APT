<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

/* ========= Helpers de unidades ========= */

// Normaliza unidades de entrada
function norm_unit(string $u): string {
  $u = strtolower(trim($u));
  $map = [
    'gr' => 'g','grs'=>'g','gramo'=>'g','gramos'=>'g',
    'kg'=>'kg','kilo'=>'kg','kilos'=>'kg','kilogramo'=>'kg','kilogramos'=>'kg',
    'lt'=>'l','l'=>'l','lts'=>'l','litro'=>'l','litros'=>'l',
    'ml'=>'ml',
    'unidad'=>'und','unid'=>'und','unidades'=>'und','und'=>'und','unds'=>'und',
    'paquete'=>'und','pote'=>'und'
  ];
  return $map[$u] ?? $u;
}

// Convierte a unidad base (g, ml, und)
function to_base(float $qty, string $unit): array {
  $unit = norm_unit($unit);

  if ($unit === 'kg') return [$qty * 1000, 'g'];
  if ($unit === 'l')  return [$qty * 1000, 'ml'];

  if ($unit === 'g' || $unit === 'ml' || $unit === 'und') {
    return [$qty, $unit];
  }

  // cualquier otra unidad rara → tratar como und
  return [max(1, $qty ?: 1), 'und'];
}

// Parser de líneas tipo "1 kg arroz", "500 g pollo", "3 zanahoria"
function parse_line($line) {
  $line = trim($line);
  if ($line === '') return null;

  $parts = preg_split('/\s+/', $line);
  $qty   = 1;
  $unit  = 'und';

  // 1) cantidad
  if (isset($parts[0]) && preg_match('/^\d+([.,]\d+)?$/', $parts[0])) {
    $qty = floatval(str_replace(',', '.', $parts[0]));
    array_shift($parts);
  }

  // 2) unidad (opcional)
  if (isset($parts[0])) {
    $candidate = strtolower($parts[0]);
    $norm = norm_unit($candidate);

    if ($norm !== $candidate || in_array($norm, ['g','kg','ml','l','und'])) {
      $unit = $norm;
      array_shift($parts);
    }
  }
    // 🔥 Heurística: si la IA manda gramos MUY pequeños (3 g, 5 g, etc.)
  // asumimos que perdió ceros: 3 → 300, 5 → 500.
  if ($unit === 'g' && $qty > 0 && $qty < 10) {
    $qty *= 100;
  }


  // 🔥 Heurística: si la IA manda gramos MUY pequeños (3 g, 5 g, etc.),
  // asumimos que perdió ceros: 3 → 300, 5 → 500.
  if ($unit === 'g' && $qty > 0 && $qty < 10) {
    $qty *= 100;
  }

  // 3) nombre del ingrediente
  $name = trim(implode(' ', $parts));
  if ($name === '') {
    $name = $line;
  }

  [$amount, $base] = to_base($qty, $unit);
  return [
    'name'   => $name,
    'amount' => $amount,
    'unit'   => $base
  ];
}


/* ========= Controlador principal ========= */

try {
  $db   = db();
  $raw  = file_get_contents('php://input');
  $data = json_decode($raw, true);
  $items = $data['items'] ?? [];

  if (!is_array($items) || empty($items)) {
    respond(['ok'=>false,'message'=>'Sin items','raw'=>$raw],400);
  }

  $added = 0;

  foreach ($items as $it) {

    $parsed = null;

    /* ===== Caso NUEVO: objeto estructurado { name, qty, unit } ===== */
    if (is_array($it) && (isset($it['name']) || isset($it['nombre']))) {
      $name = trim($it['name'] ?? $it['nombre'] ?? '');
      if ($name === '') continue;

      $qtyRaw  = $it['amount'] ?? $it['qty'] ?? $it['cantidad'] ?? 1;
      $unitRaw = $it['unit']   ?? $it['unidad'] ?? 'und';

      $qty  = (float)$qtyRaw;
      $unit = norm_unit((string)$unitRaw);

      // pequeña red de seguridad: si llega "g" y <10, asumimos que faltan ceros
      if ($unit === 'g' && $qty > 0 && $qty < 10) {
        $qty *= 100;
      }

      [$amount, $base] = to_base($qty, $unit);

      $parsed = [
        'name'   => $name,
        'amount' => $amount,
        'unit'   => $base
      ];

    } else {
      /* ===== Caso LEGACY: línea de texto libre ===== */
      $parsed = parse_line((string)$it);
      if (!$parsed) continue;
    }

    $name   = $parsed['name'];
    $amount = $parsed['amount'];
    $unit   = $parsed['unit'];

    // Último airbag por si acaso aún quedaron <10 g
    if ($unit === 'g' && $amount > 0 && $amount < 10) {
      $amount *= 100;
    }

    // Upsert por (name, unit)
    $stmt = $db->prepare("SELECT id, amount FROM pantry_item WHERE name=? AND unit=? LIMIT 1");
    $stmt->execute([$name, $unit]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
      $new = $row['amount'] + $amount;
      $db->prepare("UPDATE pantry_item SET amount=? WHERE id=?")->execute([$new, $row['id']]);
    } else {
      $db->prepare("INSERT INTO pantry_item (name, amount, unit) VALUES (?,?,?)")
         ->execute([$name, $amount, $unit]);
    }

    $added++;
  }

  respond(['ok'=>true,'added'=>$added], 200);

} catch (Throwable $e) {
  respond(['ok'=>false,'error'=>$e->getMessage()], 500);
}
