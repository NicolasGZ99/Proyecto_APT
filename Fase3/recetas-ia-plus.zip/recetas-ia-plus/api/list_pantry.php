<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

/**
 * Dev helpers
 */
function has_column(PDO $db, string $table, string $col): bool {
  $q = $db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
  $q->execute([$table, $col]);
  return (bool)$q->fetchColumn();
}

function norm_unit(?string $u): string {
  $u = strtolower(trim((string)$u));
  if ($u === '' || $u === 'u' || $u === 'unidad' || $u === 'unidades' || $u === 'und' || $u === 'unds') return 'und';
  if ($u === 'gr' || $u === 'grs' || $u === 'gramo' || $u === 'gramos' || $u === 'g') return 'g';
  if ($u === 'lt' || $u === 'lts' || $u === 'l' || $u === 'litro' || $u === 'litros') return 'ml'; // normalizamos a ml
  if ($u === 'ml' || $u === 'mililitro' || $u === 'mililitros') return 'ml';
  return $u ?: 'und';
}

function fmt_num($n, $dec = 2) {
  $s = number_format((float)$n, $dec, '.', '');
  $s = rtrim(rtrim($s, '0'), '.');
  return $s === '' ? '0' : $s;
}

function format_amount(float $amount, string $unit): string {
  if ($unit === 'g')  return $amount >= 1000 ? fmt_num($amount/1000, 2).' kg' : fmt_num($amount, 0).' g';
  if ($unit === 'ml') return $amount >= 1000 ? fmt_num($amount/1000, 2).' L'  : fmt_num($amount, 0).' ml';
  if ($unit === 'und') return fmt_num($amount, 0).' und';
  // fallback
  return fmt_num($amount, 2).' '.$unit;
}

try {
  $db = db();

  $hasAmount = has_column($db, 'pantry_item', 'amount');
  $hasUnit   = has_column($db, 'pantry_item', 'unit');

  // ==================== MODO NUEVO (amount + unit) ====================
  if ($hasAmount && $hasUnit) {
    $rows = $db->query("
      SELECT name,
             COALESCE(unit,'') AS unit_raw,
             SUM(amount) AS amount
      FROM pantry_item
      GROUP BY name, COALESCE(unit,'')
      HAVING SUM(amount) > 0
      ORDER BY name ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $items = [];
    foreach ($rows as $r) {
      $name     = (string)$r['name'];
      $unitRaw  = (string)$r['unit_raw'];
      $unit     = norm_unit($unitRaw);
      $amount   = (float)$r['amount'];

      // 🔥 Airbag total: si hay gramos ridículos (<10 g), asumimos que faltan ceros
      if ($unit === 'g' && $amount > 0 && $amount < 10) {
        // corregimos la cantidad que devolvemos...
        $amount *= 100.0;

        // ...y de paso arreglamos la BD para ese nombre
        $fix = $db->prepare("
          UPDATE pantry_item
          SET amount = amount * 100
          WHERE name = ? AND (unit = ? OR unit = '' OR unit IS NULL)
        ");
        $fix->execute([$name, $unitRaw]);
      }

      // por si quedaron litros en 'l', se normaliza a ml
      if ($unit === 'l') {
        $unit   = 'ml';
        $amount = $amount * 1000.0;
      }

      $items[] = [
        'name'    => $name,
        'unit'    => $unit,
        'amount'  => $amount,
        'display' => format_amount($amount, $unit),

        // Compatibilidad con front antiguo
        'qty'     => (int)round($amount),
      ];
    }

    echo json_encode(['ok'=>true, 'items'=>$items], JSON_UNESCAPED_UNICODE);
    exit;
  }

  // ==================== MODO LEGACY (solo name + qty) ====================
  $rows = $db->query("SELECT name, qty FROM pantry_item ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode(['ok'=>true, 'items'=>$rows], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false, 'items'=>[], 'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
