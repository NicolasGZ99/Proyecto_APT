<?php
require_once __DIR__."/config.php"; try{ $rows=db()->query("SELECT name FROM pantry_item ORDER BY id")->fetchAll(); respond(["items"=>array_map(fn($r)=>$r['name'],$rows)]); } catch(Throwable $e){ respond(["error"=>$e->getMessage()],500); }
