<?php
require_once __DIR__ . '/config.php';

try {
    $db = db();

    // Aseguramos sesión
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $userId = $_SESSION['user_id'] ?? null;
    if (!$userId) {
        respond(['error' => 'not_logged_in'], 401);
    }

    // Leer JSON
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);

    // Permitir también form-data / x-www-form-urlencoded
    if (!is_array($data) && !empty($_POST)) {
        $data = $_POST;
    }

    if (!is_array($data)) {
        respond(['error' => 'invalid_json', 'raw' => $raw], 400);
    }

    $action = $data['action'] ?? 'list';

    // ========== LISTAR ==========
    if ($action === 'list') {
        $stmt = $db->prepare("
            SELECT id, recipe_title, recipe_json, created_at
            FROM favorite
            WHERE user_id = :uid
            ORDER BY created_at DESC, id DESC
            LIMIT 5
        ");
        $stmt->execute([':uid' => $userId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        respond(['ok' => true, 'items' => $rows]);
    }

    // ========== AGREGAR ==========
    if ($action === 'add') {
        $title  = trim($data['title'] ?? '');
        $recipe = $data['data'] ?? null;

        if ($title === '' || $recipe === null) {
            respond(['error' => 'missing_fields'], 400);
        }

        $json = json_encode($recipe, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $stmt = $db->prepare("
            INSERT INTO favorite (user_id, recipe_title, recipe_json)
            VALUES (:uid, :title, :json)
        ");
        $stmt->execute([
            ':uid'   => $userId,
            ':title' => $title,
            ':json'  => $json
        ]);

        respond(['ok' => true, 'id' => $db->lastInsertId()]);
    }

    // (Opcional) Eliminar un favorito
    if ($action === 'delete') {
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            respond(['error' => 'missing_id'], 400);
        }
        $stmt = $db->prepare("
            DELETE FROM favorite
            WHERE id = :id AND user_id = :uid
        ");
        $stmt->execute([
            ':id'  => $id,
            ':uid' => $userId
        ]);
        respond(['ok' => true]);
    }

    respond(['error' => 'invalid_action'], 400);

} catch (Throwable $e) {
    respond(['error' => $e->getMessage()], 500);
}
