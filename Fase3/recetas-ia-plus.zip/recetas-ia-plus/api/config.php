<?php
session_start();

function current_user_id() {
  return $_SESSION['user_id'] ?? null;
}

function require_user() {
  $uid = current_user_id();
  if (!$uid) {
    respond(['error'=>'not_authenticated'], 401);
  }
  return $uid;
}
// config.php - example, fill values and move outside /public in production
function db(){
  static $pdo = null;
  if ($pdo) return $pdo;
  $host = '127.0.0.1';
  $db   = 'recetas_db';
  $user = 'root';
  $pass = '';
  $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
  $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  return $pdo;
}
function respond($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}
// OpenAI settings
$OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: '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';
$OPENAI_MODEL = getenv('OPENAI_MODEL') ?: 'gpt-4o-mini';
$OPENAI_URL = getenv('OPENAI_URL') ?: 'https://api.openai.com/v1/chat/completions';
