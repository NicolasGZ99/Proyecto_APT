<?php
require_once __DIR__ . '/config.php';

function pick_uploaded_file(array $names) {
  foreach ($names as $n) {
    if (isset($_FILES[$n]) && $_FILES[$n]['error'] === UPLOAD_ERR_OK) return $n;
  }
  return null;
}

try {
  $OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: ($OPENAI_API_KEY ?? '');
  $OPENAI_MODEL   = getenv('OPENAI_MODEL') ?: ($OPENAI_MODEL ?? 'gpt-4o-mini'); // visión OK
  $OPENAI_URL     = getenv('OPENAI_URL') ?: ($OPENAI_URL ?? 'https://api.openai.com/v1/chat/completions');
  if (!$OPENAI_API_KEY) respond(['error'=>'Falta OPENAI_API_KEY'], 500);

  // 1) Detectar archivo
  $field = pick_uploaded_file(['receipt','file','boleta','image']);
  if ($field === null) {
    respond([
      'ok'=>false,
      'message'=>'No se recibió archivo. Verifica el name del input y el enctype.',
      'received_files'=>array_keys($_FILES)
    ], 400);
  }

  // 2) Validar tamaño y MIME
  if ($_FILES[$field]['size'] > 10 * 1024 * 1024) {
    respond(['ok'=>false,'message'=>'Archivo demasiado grande (>10MB)'], 400);
  }

  $path = $_FILES[$field]['tmp_name'];
  $mime = mime_content_type($path) ?: ($_FILES[$field]['type'] ?? 'application/octet-stream');

  // 3) Normalizar a IMAGEN (GPT visión necesita imagen, no PDF)
  $bytes = false;

  if ($mime === 'application/pdf') {
    if (extension_loaded('imagick')) {
      $im = new Imagick();
      $im->setResolution(200, 200);
      $im->readImage($path."[0]"); // primera página
      $im->setImageFormat('jpeg');
      $bytes = $im->getImageBlob();
      $mime  = 'image/jpeg';
      $im->clear(); $im->destroy();
    } else {
      respond([
        'ok'=>false,
        'code'=>'pdf_not_supported_server',
        'message'=>'El servidor no puede convertir PDF. Envía la boleta como imagen (o convierte el PDF a imagen en el navegador).'
      ], 415);
    }
  } else {
    if (!preg_match('~^image/(jpeg|png|webp)$~i', $mime)) {
      respond(['ok'=>false,'message'=>"Formato no soportado ($mime). Usa JPG, PNG, WEBP o PDF."], 400);
    }
    $bytes = file_get_contents($path);
  }

  if ($bytes === false) {
    respond(['ok'=>false,'message'=>'No se pudo leer el archivo.'], 500);
  }

  $dataUrl = 'data:' . $mime . ';base64,' . base64_encode($bytes);

  // 4) Mensajes para visión (JSON estricto)
  $system = [
  'role' => 'system',
  'content' =>
"Eres un extractor OCR especializado en boletas chilenas.
Tu tarea es devolver SOLO los productos alimenticios detectados con su cantidad TOTAL comprada.

Ignora precios, valores monetarios, subtotales, totales, descuentos,
unidades monetarias o cualquier dato que no sea descripción y cantidad.

Responde EXCLUSIVAMENTE con un JSON válido y nada más.
Formato exacto:
{
  \"items\": [{\"nombre\": string, \"cantidad\": number, \"unidad\": string}],
  \"confianza\": number
}

Reglas IMPORTANTES:

- Para cada producto, observa TODAS las líneas asociadas.
  Ejemplo real:
    \"FRUTILLA 300 GR\"
    \"1,496 KG X $ 1.590\"
  Aquí la cantidad TOTAL comprada es 1,496 KG, es decir 1496 gramos.
  Debes devolver: {\"nombre\": \"frutilla\", \"cantidad\": 1496, \"unidad\": \"g\"}.

- Si ves patrones como \"0,916 KG\", \"1,496 KG\", \"0,460 KG\":
  - Convierte SIEMPRE a gramos (g).
  - 0,916 KG → 916 g
  - 1,496 KG → 1496 g
  - 0,460 KG → 460 g

- Si ves patrones como \"300 GR\", \"125 GR\", \"500G\":
  - Usa el número completo:
    \"300 GR\" → cantidad = 300, unidad = \"g\"
    \"500G\"   → cantidad = 500, unidad = \"g\"
    \"125 GR\" → cantidad = 125, unidad = \"g\"
  NUNCA reduzcas estos a 3 g, 5 g, etc.

- Si el producto está por volumen (LT, L, ML):
  - Convierte SIEMPRE a mililitros (ml).
    \"0,5 L\" → 500 ml
    \"1 L\"   → 1000 ml
    \"500 ML\" → 500 ml

- Si el producto está por unidades (\"3 X\", \"3 UNID\", \"3 UND\"):
  - cantidad = número de unidades
  - unidad  = \"und\"

- Simplifica nombres largos o con marca (\"SOPROLE DURAZNO 155G\" → \"yogur sabor durazno\"), 
  pero NO pierdas la relación con su cantidad.

- Si no hay productos alimenticios, devuelve \"items\": []."
];




  $user = [
    'role'=>'user',
    'content'=>[
      ['type'=>'text', 'text'=>'Extrae los productos alimenticios de esta boleta. Responde SOLO JSON.'],
      ['type'=>'image_url','image_url'=>['url'=>$dataUrl,'detail'=>'high']]
    ]
  ];

  // 5) Payload: forzar JSON mode
  $payload = [
    'model' => $OPENAI_MODEL,
    'messages' => [$system, $user],
    'temperature' => 0.0,
    'response_format' => [ 'type' => 'json_object' ],
  ];

  $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
  if ($json === false) {
    respond(['error'=>'JSON encode error', 'detail'=>json_last_error_msg()], 500);
  }

// 6) Llamar a OpenAI
$ch = curl_init($OPENAI_URL);

curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $OPENAI_API_KEY,
  ],
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => $json, // o json_encode($payload, JSON_UNESCAPED_UNICODE)
]);




  $raw  = curl_exec($ch);
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err  = curl_error($ch);
  curl_close($ch);

  if ($raw === false) {
    respond(array('error' => 'cURL error', 'detail' => $err), 502);
  }

  $resp = json_decode($raw, true);
  if (json_last_error() !== JSON_ERROR_NONE) {
    respond(array('http_code' => $http, 'raw_response' => $raw), 500);
  }

  if (isset($resp['error'])) {
    respond(array('http_code' => $http, 'openai_error' => $resp['error']), 500);
  }

  $content = isset($resp['choices'][0]['message']['content'])
    ? $resp['choices'][0]['message']['content']
    : '';

  if ($content === '') {
    respond(['ok'=>false, 'message'=>'Respuesta vacía de OpenAI'], 500);
  }

  // --------- PARSEO ROBUSTO (sin volver a pisar $data) ----------
  // 1) Intento directo
  $data = json_decode($content, true);

  // 2) Si falla, limpiar cercas ```json ... ```
  if (json_last_error() !== JSON_ERROR_NONE) {
    $clean = trim($content);
    $clean = preg_replace('~^```(?:json)?\s*~i', '', $clean);
    $clean = preg_replace('~\s*```$~', '', $clean);
    $clean = trim($clean);
    $data = json_decode($clean, true);

    // 3) Si aún falla, intenta extraer el primer {...}
    if (json_last_error() !== JSON_ERROR_NONE && preg_match('~\{.*\}~s', $content, $m)) {
      $maybe = $m[0];
      $data = json_decode($maybe, true);
    }
  }

  if (json_last_error() !== JSON_ERROR_NONE) {
    respond([
      'ok'=>false,
      'message'=>'El modelo no devolvió JSON válido',
      'content_raw'=>$content
    ], 200);
  }
  // ---------------------------------------------------------------

  if (empty($data['items'])) {
    respond(['ok'=>false, 'message'=>'No se detectaron ingredientes', 'parsed'=>$data], 200);
  }

 // Adaptar a lo que espera main.js  -> items: [{name, qty, unit}]
$items = array_map(function($it){
  $nombre   = isset($it['nombre']) ? trim((string)$it['nombre']) : '';
  $cantidad = isset($it['cantidad']) ? (float)$it['cantidad'] : 1;
  if ($cantidad <= 0) $cantidad = 1;
  $unidad   = isset($it['unidad']) ? trim((string)$it['unidad']) : '';

  $unidadRaw = strtolower($unidad);

    // Normalización de unidades a base (g, ml, und)
  $unidad = '';
  switch ($unidadRaw) {
    // gramos
    case 'g':
    case 'gr':
    case 'grs':
    case 'gramo':
    case 'gramos':
      // Heurística: si el modelo devolvió muy pocos gramos (3, 5, etc.)
      // es muy probable que venga de "300 GR", "500G", etc.
      if ($cantidad > 0 && $cantidad < 10) {
        $cantidad *= 100;
      }
      $unidad = 'g';
      break;


    // kilogramos -> convertir a g
    case 'kg':
    case 'kgs':
    case 'kilo':
    case 'kilos':
    case 'kilogramo':
    case 'kilogramos':
      $cantidad = $cantidad * 1000;
      $unidad   = 'g';
      break;

    // mililitros
    case 'ml':
    case 'mililitro':
    case 'mililitros':
      $unidad = 'ml';
      break;

    // litros -> convertir a ml
    case 'l':
    case 'lt':
    case 'lts':
    case 'litro':
    case 'litros':
      $cantidad = $cantidad * 1000;
      $unidad   = 'ml';
      break;

    // unidades
    case 'u':
    case 'und':
    case 'unds':
    case 'unidad':
    case 'unidades':
    case 'paquete':
    case 'pote':
      $unidad = 'und';
      break;

    default:
      $unidad = $unidadRaw !== '' ? $unidadRaw : 'und';
      break;
  }

  if ($cantidad <= 0) {
    $cantidad = 1;
  }

  return [
    'name' => $nombre,
    'qty'  => $cantidad,
    'unit' => $unidad
  ];
}, $data['items'] ?? []);



  respond(['ok' => true, 'items' => $items, 'resultado' => $data], 200);

} catch (Throwable $e) {
  respond(array('error' => 'exception', 'detail' => $e->getMessage()), 500);
}
