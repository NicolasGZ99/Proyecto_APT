<?php
require_once __DIR__ . "/config.php";

function normalize_receta($r) {
  $titulo = $r['titulo'] ?? $r['title'] ?? $r['name'] ?? "Sin título";

  // tiempo
  $tiempo = $r['tiempo_min'] ?? $r['time_min'] ?? $r['tiempo'] ?? $r['time'] ?? null;
  if (is_string($tiempo) && preg_match('/(\d+)/', $tiempo, $m)) $tiempo = (int)$m[1];

  // porciones
  $porciones = $r['porciones'] ?? $r['servings'] ?? $r['porciones_estimadas'] ?? null;
  if (is_string($porciones) && preg_match('/(\d+)/', $porciones, $m)) $porciones = (int)$m[1];

  // ingredientes usados (solo nombres)
  $ingredientes = $r['ingredientes_usados'] ?? $r['ingredientes'] ?? $r['ingredients'] ?? [];
  if (!is_array($ingredientes)) $ingredientes = [];

  // pasos
  $pasos = $r['pasos'] ?? $r['steps'] ?? [];
  if (!is_array($pasos)) $pasos = [];

  // sustituciones
  $sust = $r['sustituciones'] ?? $r['substitutions'] ?? [];
  if (!is_array($sust)) $sust = [];

  // 🔹 ingredientes_detalle: [{name, amount, unit, amount_display}]
  $ingred_detalle_raw = $r['ingredientes_detalle'] ?? $r['ingredientes_detallados'] ?? $r['ingredients_detail'] ?? [];
  $ingredientes_detalle = [];

  if (is_array($ingred_detalle_raw)) {
    foreach ($ingred_detalle_raw as $it) {
      if (!is_array($it)) continue;

      $name = trim($it['name'] ?? $it['ingrediente'] ?? $it['nombre'] ?? '');
      if ($name === '') continue;

      $amount = $it['amount'] ?? $it['qty'] ?? $it['cantidad'] ?? 0;
      $amount = is_numeric($amount) ? (float)$amount : 0.0;

      $unit = strtolower(trim($it['unit'] ?? $it['unidad'] ?? 'und'));
      if ($unit === '') $unit = 'und';

      $amount_display = $it['amount_display'] ?? $it['texto'] ?? null;
      if (!$amount_display && $amount > 0) {
        // formateo simple: 120 g, 80 ml, 2 und
        $amt_str = (fmod($amount, 1) === 0.0) ? (string)intval($amount) : (string)$amount;
        $amount_display = trim($amt_str . ' ' . $unit);
      }

      $ingredientes_detalle[] = [
        'name'           => $name,
        'amount'         => $amount,
        'unit'           => $unit,
        'amount_display' => $amount_display
      ];
    }
  }

  // 🔹 nutricion: {kcal, proteina_g, carbohidratos_g, grasas_g}
  $nut_raw = $r['nutricion'] ?? $r['nutrition'] ?? [];
  $nutricion = null;
  if (is_array($nut_raw)) {
    $kcal = $nut_raw['kcal'] ?? $nut_raw['calorias'] ?? $nut_raw['energia_kcal'] ?? null;

    $prot = $nut_raw['proteina_g'] ?? $nut_raw['proteinas_g'] ?? $nut_raw['protein_g'] ?? $nut_raw['protein'] ?? null;
    $carb = $nut_raw['carbohidratos_g'] ?? $nut_raw['carbohidratos'] ?? $nut_raw['carbs_g'] ?? $nut_raw['carbs'] ?? null;
    $gras = $nut_raw['grasas_g'] ?? $nut_raw['grasas'] ?? $nut_raw['fat_g'] ?? $nut_raw['fat'] ?? null;

    $nutricion = [
      'kcal'             => is_numeric($kcal) ? (float)$kcal : null,
      'proteina_g'       => is_numeric($prot) ? (float)$prot : null,
      'carbohidratos_g'  => is_numeric($carb) ? (float)$carb : null,
      'grasas_g'         => is_numeric($gras) ? (float)$gras : null,
    ];
  }

  return [
    "titulo"              => $titulo,
    "tiempo_min"          => $tiempo,
    "porciones"           => $porciones,
    "ingredientes_usados" => $ingredientes,
    "sustituciones"       => $sust,
    "pasos"               => $pasos,
    "ingredientes_detalle"=> $ingredientes_detalle,
    "nutricion"           => $nutricion
  ];
}

try {
  $pdo = db();

  // 0) Leer dieta desde el body (opcional)
  $input = json_decode(file_get_contents('php://input'), true);
  $diet  = $input['diet'] ?? 'ninguna';

  // Mapeo bonito para el prompt
  $diet_label = match ($diet) {
    'vegetariano' => 'vegetariano (sin carnes ni pescados, permite lácteos y huevos)',
    'vegano'      => 'vegano (sin ningún producto de origen animal: sin carne, pescado, huevo, leche, queso, miel, etc.)',
    'sin_gluten'  => 'sin gluten (evitar trigo, cebada, centeno y derivados como pan, masa de pizza, etc.)',
    'sin_lactosa' => 'sin lactosa (evitar leche y lácteos comunes; usar alternativas sin lactosa o vegetales)',
    'keto'        => 'keto / baja en carbohidratos (evitar azúcar, harinas, pan, arroz, pasta; priorizar proteínas y grasas saludables)',
    default       => 'sin restricciones especiales (omnívoro)'
  };

  // 1) Ingredientes desde la BD (solo nombres, pero el modelo inferirá cantidades)
  $rows = $pdo->query("SELECT name FROM pantry_item ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
  $ingredients = array_map(fn($r) => $r['name'], $rows);

  // 2) Prompt a la IA: 3 recetas, respetando dieta, con cantidades + nutrición
  global $OPENAI_API_KEY, $OPENAI_MODEL, $OPENAI_URL;

  $system = [
    "role" => "system",
    "content" =>
      "Eres un chef profesional y nutricionista.\n" .
      "Debes generar recetas usando SOLO los ingredientes disponibles que te envío.\n" .
      "Debes respetar la dieta del usuario. Si la dieta es vegana, no puedes usar NINGÚN producto animal (ni lácteos ni miel). " .
      "Si es vegetariana, no uses carnes ni pescados. Si es sin gluten, evita trigo, cebada, centeno y sus derivados. " .
      "Si es sin lactosa, evita leche y lácteos comunes. Si es keto, evita ingredientes altos en carbohidratos.\n\n" .
      "Responde EXCLUSIVAMENTE en JSON válido con este esquema EXACTO:\n" .
      "{\n" .
      "  \"recetas\": [\n" .
      "    {\n" .
      "      \"titulo\": \"string\",\n" .
      "      \"tiempo_min\": number,\n" .
      "      \"porciones\": number,\n" .
      "      \"ingredientes_usados\": [\"string\"],\n" .
      "      \"ingredientes_detalle\": [\n" .
      "        {\n" .
      "          \"name\": \"string\",              // nombre del ingrediente, igual o muy parecido a la despensa\n" .
      "          \"amount\": number,               // cantidad NUMÉRICA en unidad base\n" .
      "          \"unit\": \"g\"|\"ml\"|\"und\",   // g para sólidos, ml para líquidos, und para unidades\n" .
      "          \"amount_display\": \"string\"    // texto amigable: ej. \"120 g\", \"200 ml\", \"2 und\"\n" .
      "        }\n" .
      "      ],\n" .
      "      \"sustituciones\": [\"string\"],\n" .
      "      \"pasos\": [\"string\"],\n" .
      "      \"nutricion\": {\n" .
      "        \"kcal\": number,              // calorías estimadas de la receta completa\n" .
      "        \"proteina_g\": number,        // gramos de proteína\n" .
      "        \"carbohidratos_g\": number,   // gramos de carbohidratos\n" .
      "        \"grasas_g\": number           // gramos de grasas\n" .
      "      }\n" .
      "    }\n" .
      "  ]\n" .
      "}\n\n" .
      "Reglas:\n" .
      "- Entrega EXACTAMENTE 3 recetas.\n" .
      "- No incluyas texto fuera del JSON.\n" .
      "- Cada paso debe ser claro y numerable.\n" .
      "- Usa SOLO los ingredientes disponibles (puedes asumir agua, sal, aceite).\n" .
      "- Para 'amount' siempre usa unidades base: 'g', 'ml' o 'und'.\n"
  ];

  $userPayload = [
    "ingredientes" => $ingredients,
    "filtros" => [
      "max_tiempo"        => 60,
      "porciones"         => 2,
      "dieta"             => $diet,
      "descripcion_dieta" => $diet_label
    ]
  ];

  $user = [
    "role" => "user",
    "content" => json_encode($userPayload, JSON_UNESCAPED_UNICODE)
  ];

  $body = [
    "model"           => $OPENAI_MODEL,
    "temperature"     => 0.4,
    "response_format" => [ "type" => "json_object" ],
    "messages"        => [$system, $user]
  ];

  // 3) Llamada a OpenAI
  $ch = curl_init($OPENAI_URL);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
      "Authorization: Bearer " . $OPENAI_API_KEY,
      "Content-Type: application/json"
    ],
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE)
  ]);
  $raw = curl_exec($ch);
  if ($raw === false) throw new Exception("cURL: " . curl_error($ch));
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($http >= 300) {
    respond(["error" => "OpenAI HTTP $http", "raw" => $raw], 500);
  }

  // 4) Decodificar respuesta (ya debería venir en JSON puro)
  $json    = json_decode($raw, true);
  $content = $json["choices"][0]["message"]["content"] ?? "{}";

  $data = json_decode($content, true);

  // Fallback por si igual viniera envuelto en texto raro
  if (!is_array($data) && preg_match('/\{.*\}/s', $content, $m)) {
    $data = json_decode($m[0], true);
  }

  $recetas = [];

  if (is_array($data)) {
    // Caso A: objeto con clave "recetas"
    if (isset($data["recetas"])) {
      $recList = $data["recetas"];
      // Si "recetas" es un único objeto, envolver
      if (is_array($recList) && array_keys($recList) !== range(0, count($recList)-1)) {
        $recList = [$recList];
      }
      foreach ((array)$recList as $r) {
        $recetas[] = normalize_receta($r);
      }
    }
    // Caso B: devolvió directamente un array de recetas
    elseif (array_keys($data) === range(0, count($data)-1)) {
      foreach ($data as $r) {
        $recetas[] = normalize_receta($r);
      }
    }
  }

  // 5) Log completo para depurar
  $stmt = $pdo->prepare("
    INSERT INTO suggestion_log (ingredients, model, prompt, response_json)
    VALUES (?,?,?,?)
  ");
  $stmt->execute([
    json_encode($ingredients, JSON_UNESCAPED_UNICODE),
    $OPENAI_MODEL,
    json_encode($body, JSON_UNESCAPED_UNICODE),
    $raw
  ]);

  // 6) Guardar en historial
  if (!empty($recetas)) {
    $stmt2 = $pdo->prepare("INSERT INTO recipe_history (recipe_title, data_json) VALUES (?,?)");
    foreach ($recetas as $r) {
      $stmt2->execute([$r['titulo'], json_encode($r, JSON_UNESCAPED_UNICODE)]);
    }
  }

  respond(["recetas" => $recetas]);
} catch (Throwable $e) {
  respond(["error" => $e->getMessage()], 500);
}
