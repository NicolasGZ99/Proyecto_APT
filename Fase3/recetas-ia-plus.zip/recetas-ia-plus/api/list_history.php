<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

try {
  $db = db();

  // Ajusta el nombre de la tabla/columnas si en tu BD se llaman distinto
  $rows = $db->query("
    SELECT id, recipe_title, created_at
    FROM recipe_history
    ORDER BY created_at DESC
    LIMIT 5
  ")->fetchAll(PDO::FETCH_ASSOC);

  $items = array_map(fn($r) => [
    'id'          => $r['id'],
    'recipe_title'=> $r['recipe_title'] ?? 'Receta',
    'created_at'  => $r['created_at']   ?? null,
  ], $rows);

  respond(['ok' => true, 'items' => $items]);

} catch (Throwable $e) {
  respond(['ok' => false, 'error' => $e->getMessage()]);
}
