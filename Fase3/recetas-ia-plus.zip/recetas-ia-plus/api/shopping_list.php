<?php
require_once __DIR__."/config.php"; $in=json_input(); $recipes=$in['recipes']??[]; $lista=[];
foreach($recipes as $r){ foreach(($r['ingredientes_usados']??[]) as $ing){ $k=mb_strtolower(trim($ing)); if(!isset($lista[$k])) $lista[$k]=0; $lista[$k]++; } }
$out=[]; foreach($lista as $name=>$qty){ $out[]=["name"=>$name,"qty"=>$qty]; } respond(["items"=>$out]);
