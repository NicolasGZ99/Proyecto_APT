<?php
require_once __DIR__ . "/config.php";
header("Content-Type: application/json; charset=utf-8");

try {
    $db   = db();
    $data = json_decode(file_get_contents("php://input"), true) ?? [];

    $op   = $data["op"]   ?? "";
    $name = trim($data["name"] ?? "");
    $unit = strtolower(trim($data["unit"] ?? "")); // g, ml, und

    if ($name === "" || $op === "") {
        throw new Exception("Parámetros inválidos");
    }
    if ($unit === "") {
        $unit = "und"; // por si viniera vacío
    }

    if ($op === "del") {
        // Eliminar ingrediente (name + unit)
        $stmt = $db->prepare("DELETE FROM pantry_item WHERE name = ? AND unit = ?");
        $stmt->execute([$name, $unit]);

        echo json_encode(["ok" => true]);
        exit;
    }

    if ($op === "delta") {
        if (!isset($data["delta"]) || !is_numeric($data["delta"])) {
            throw new Exception("Parámetros inválidos");
        }

        $delta = (float)$data["delta"];
        if ($delta == 0) {
            echo json_encode(["ok" => true]);
            exit;
        }

        // Buscar registro actual
        $stmt = $db->prepare("SELECT id, amount FROM pantry_item WHERE name = ? AND unit = ? LIMIT 1");
        $stmt->execute([$name, $unit]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $newAmount = $row["amount"] + $delta;

            if ($newAmount <= 0) {
                // Si llega a 0 o menos, borrar
                $del = $db->prepare("DELETE FROM pantry_item WHERE id = ?");
                $del->execute([$row["id"]]);
            } else {
                $upd = $db->prepare("UPDATE pantry_item SET amount = ? WHERE id = ?");
                $upd->execute([$newAmount, $row["id"]]);
            }
        } else {
            // Si no existe y el delta es positivo, crearlo
            if ($delta > 0) {
                $ins = $db->prepare("INSERT INTO pantry_item (name, amount, unit) VALUES (?, ?, ?)");
                $ins->execute([$name, $delta, $unit]);
            }
        }

        echo json_encode(["ok" => true]);
        exit;
    }

    // Si llega aquí, op no soportado
    throw new Exception("Operación no soportada");

} catch (Throwable $e) {
    echo json_encode(["ok" => false, "error" => $e->getMessage()]);
}
