<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
session_start();

if (empty($_SESSION['user_id'])) {
    respond(['ok' => false, 'user' => null]);
}

$db = db();
$stmt = $db->prepare("SELECT id, email FROM user WHERE id = ? LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Sesión colgada
    $_SESSION = [];
    session_destroy();
    respond(['ok' => false, 'user' => null]);
}

respond(['ok' => true, 'user' => $user]);
