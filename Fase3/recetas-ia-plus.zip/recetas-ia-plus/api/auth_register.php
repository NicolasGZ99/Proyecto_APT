<?php
require_once __DIR__ . '/config.php';

try {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);

    if (!is_array($data)) {
        respond(['error' => 'invalid_json', 'raw' => $raw], 400);
    }

    $email = isset($data['email']) ? trim($data['email']) : '';
    $pass  = isset($data['password']) ? (string)$data['password'] : '';
    $name  = isset($data['name']) ? trim($data['name']) : '';

    if ($email === '' || $pass === '') {
        respond(['error' => 'missing_fields'], 400);
    }

    if ($name === '') {
        respond(['error' => 'missing_name'], 400);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond(['error' => 'invalid_email'], 400);
    }

    if (strlen($pass) < 6) {
        respond(['error' => 'weak_password'], 400);
    }

    $db = db();

    $check = $db->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
    $check->execute([':email' => $email]);
    if ($check->fetch()) {
        respond(['error' => 'email_taken'], 409);
    }

    $hash = password_hash($pass, PASSWORD_DEFAULT);

    $ins = $db->prepare('
        INSERT INTO users (email, password_hash, display_name)
        VALUES (:email, :hash, :name)
    ');
    $ins->execute([
        ':email' => $email,
        ':hash'  => $hash,
        ':name'  => $name,
    ]);

    $userId = (int)$db->lastInsertId();

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['user_id'] = $userId;

    respond([
        'ok'   => true,
        'user' => [
            'id'    => $userId,
            'email' => $email,
            'name'  => $name,
        ],
    ]);

} catch (Throwable $e) {
    respond([
        'error'  => 'server_error',
        'detail' => $e->getMessage(),
    ], 500);
}
