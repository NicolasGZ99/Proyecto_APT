<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

try {
  $OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: ($OPENAI_API_KEY ?? '');
  if (!$OPENAI_API_KEY) {
    respond(['ok'=>false,'error'=>'Falta OPENAI_API_KEY'], 500);
  }

  $input = json_decode(file_get_contents('php://input'), true) ?: [];
  $title = trim($input['title'] ?? '');
  $desc  = trim($input['description'] ?? '');

  if ($title === '') {
    respond(['ok'=>false,'error'=>'Título vacío'], 400);
  }

  // Prompt para la imagen
  $prompt = "Foto vertical de alta calidad, estilo app de recetas, iluminación natural, comida muy apetecible. Plato: $title.";
  if ($desc !== '') {
    $prompt .= " Ingredientes principales: $desc.";
  }

  $payload = [
    'model'  => 'gpt-image-1',
    'prompt' => $prompt,
    'size'   => '512x512',
    'n'      => 1
  ];

  $ch = curl_init('https://api.openai.com/v1/images/generations');
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
      'Authorization: Bearer ' . $OPENAI_API_KEY,
      'Content-Type: application/json'
    ],
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE)
  ]);

  $raw  = curl_exec($ch);
  if ($raw === false) {
    throw new Exception('cURL: ' . curl_error($ch));
  }
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($http >= 300) {
    respond(['ok'=>false,'error'=>"OpenAI HTTP $http",'raw'=>$raw], $http);
  }

  $resp = json_decode($raw, true);
  $url  = $resp['data'][0]['url'] ?? null;

  if (!$url) {
    respond(['ok'=>false,'error'=>'Sin URL de imagen','raw'=>$raw], 500);
  }

  respond(['ok'=>true,'url'=>$url]);
} catch (Throwable $e) {
  respond(['ok'=>false,'error'=>$e->getMessage()], 500);
}
