<?php
require_once __DIR__ . '/config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    respond(['ok' => false, 'user' => null]);
}

$db = db();
$stmt = $db->prepare('SELECT id, email, display_name FROM users WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    respond(['ok' => false, 'user' => null]);
}

respond([
    'ok'   => true,
    'user' => [
        'id'    => (int)$user['id'],
        'email' => $user['email'],
        'name'  => $user['display_name'],
    ],
]);
