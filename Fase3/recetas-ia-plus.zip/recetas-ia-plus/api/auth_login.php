<?php
require_once __DIR__ . '/config.php';

try {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);

    if (!is_array($data)) {
        respond(['error' => 'invalid_json', 'raw' => $raw], 400);
    }

    $email = isset($data['email']) ? trim($data['email']) : '';
    $pass  = isset($data['password']) ? (string)$data['password'] : '';

    if ($email === '' || $pass === '') {
        respond(['error' => 'missing_fields'], 400);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond(['error' => 'invalid_email'], 400);
    }

    $db = db();

    $stmt = $db->prepare('
        SELECT id, email, password_hash, display_name
        FROM users
        WHERE email = :email
        LIMIT 1
    ');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($pass, $user['password_hash'])) {
        respond(['error' => 'bad_credentials'], 401);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION['user_id'] = (int)$user['id'];

    respond([
        'ok'   => true,
        'user' => [
            'id'    => (int)$user['id'],
            'email' => $user['email'],
            'name'  => $user['display_name'],
        ],
    ]);

} catch (Throwable $e) {
    respond([
        'error'  => 'server_error',
        'detail' => $e->getMessage(),
    ], 500);
}
