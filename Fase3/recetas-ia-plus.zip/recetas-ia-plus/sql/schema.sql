-- =========================================
-- Crear base de datos
-- =========================================
CREATE DATABASE IF NOT EXISTS recetas_db
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE recetas_db;

-- =========================================
-- 🥫 Tabla: pantry_item (despensa)
--  - Guarda ingredientes de la despensa
--  - amount+unit ya en unidad base (g, ml, und)
-- =========================================
CREATE TABLE IF NOT EXISTS pantry_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name   VARCHAR(255) NOT NULL,
  amount DECIMAL(10,3) DEFAULT 1,   -- ej: 125, 500, 1496...
  unit   VARCHAR(20)   DEFAULT 'und', -- g, ml, und
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_pantry (name, unit)
);

-- =========================================
-- 📜 Tabla: recipe_history (historial de recetas)
--  - Usada por suggest_recipes.php y list_history.php
-- =========================================
CREATE TABLE IF NOT EXISTS recipe_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recipe_title VARCHAR(255) NOT NULL,
  data_json    LONGTEXT,                     -- receta completa en JSON
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- ⭐ Tabla: favorite (recetas guardadas por usuario)
--  - Usada por api/favorite.php
-- =========================================
CREATE TABLE IF NOT EXISTS favorite (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,                      -- referencia a users.id
  recipe_title VARCHAR(255) NOT NULL,
  recipe_json  LONGTEXT,                     -- receta completa en JSON
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_fav_user (user_id)
  -- Si quieres forzar integridad referencial (opcional):
  -- ,CONSTRAINT fk_favorite_user
  --   FOREIGN KEY (user_id) REFERENCES users(id)
  --   ON DELETE CASCADE
);

-- =========================================
-- 🧠 Tabla: suggestion_log (log de consultas IA)
--  - Para depurar prompts y respuestas del modelo
-- =========================================
CREATE TABLE IF NOT EXISTS suggestion_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ingredients   LONGTEXT,
  model         VARCHAR(100),
  prompt        LONGTEXT,
  response_json LONGTEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- 👤 Tabla: users (registro de usuarios)
--  - Usada por auth_register.php y auth_login.php
-- =========================================
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name  VARCHAR(255) DEFAULT NULL,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- 👤 Vista de compatibilidad: user
--  - auth_me.php usa SELECT ... FROM user
--  - Creamos una VIEW que apunta a users
-- =========================================
DROP VIEW IF EXISTS user;

CREATE VIEW user AS
  SELECT id, email, password_hash, display_name, created_at
  FROM users;

-- =========================================
-- 🔧 (Opcional) Migración desde versión antigua
--  Si vienes de un esquema con columna qty en pantry_item
--  (antes de amount+unit)
-- =========================================
-- OJO: Estas sentencias solo tienen sentido si ya existe columna qty,
-- puedes omitirlas en una instalación completamente nueva.

ALTER TABLE pantry_item
  ADD COLUMN IF NOT EXISTS amount DECIMAL(10,3) DEFAULT 1,
  ADD COLUMN IF NOT EXISTS unit   VARCHAR(20)   DEFAULT 'und';

UPDATE pantry_item
  SET amount = qty
  WHERE (amount IS NULL OR amount = 0)
    AND qty IS NOT NULL;
