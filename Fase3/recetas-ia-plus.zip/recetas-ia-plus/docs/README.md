# Recetas IA Plus
Sigue README de instalación en `sql/schema.sql`, configurar `api/config.php` y abrir `/public/`.
