// Función abreviada para seleccionar elementos del DOM
const $ = (s) => document.querySelector(s);

// Ruta base de la API (se ajusta automáticamente si la carpeta está dentro de /public)
let API_BASE = "../api/";
const parts = location.pathname.split("/").filter(Boolean);
const idx = parts.lastIndexOf("public"); 
if (idx >= 0) API_BASE = "/" + parts.slice(0, idx).join("/") + "/api/";

/* ------------------------------------------------------------------
   🧹 Limpia el campo de ingredientes y vuelve a enfocar el textarea
------------------------------------------------------------------ */
function clearIngredients() {
  const input = $("#ingredients");
  input.value = "";
  input.focus();
}

/* ------------------------------------------------------------------
   📝 Genera la estructura HTML de una "tarjeta" de receta sugerida
------------------------------------------------------------------ */
function card(r, i) {
  return `
    <div class="recipe">
      <h3>${r.titulo}</h3>
      <div>
        <span class="tag">⏱ ${r.tiempo_min || "-"} min</span>
        <span class="tag">🍽 ${r.porciones || "-"} porciones</span>
      </div>
      ${(r.ingredientes_usados || []).length 
        ? `<p><b>Usa:</b> ${(r.ingredientes_usados || []).join(", ")}</p>` 
        : ""}
      <ol>${(r.pasos || []).map(p => `<li>${p}</li>`).join("")}</ol>
      <button class="btn outline" data-fav="${i}">⭐ Guardar favorito</button>
    </div>`;
}

/* ------------------------------------------------------------------
   💾 Guarda la lista de ingredientes escrita por el usuario
   → Envía datos al backend (save_pantry.php)
   → Limpia el campo al terminar
------------------------------------------------------------------ */
async function savePantry() { 
  const raw = $("#ingredients").value; 
  const items = raw.split(/[,\n]/).map(x => x.trim()).filter(Boolean);

  const r = await fetch(API_BASE + "save_pantry.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({items})
  });

  const d = await r.json(); 
  alert(d.ok ? `Guardado (${d.count})` : "Error"); 

  clearIngredients(); // 🧹 Limpia después de guardar
}

/* ------------------------------------------------------------------
   📥 Carga ingredientes guardados anteriormente en la despensa
   → Llama al backend (get_pantry.php)
   → Rellena el textarea con los ingredientes almacenados
------------------------------------------------------------------ */
async function loadPantry() { 
  const r = await fetch(API_BASE + "get_pantry.php"); 
  const d = await r.json(); 
  $("#ingredients").value = (d.items || []).join(", "); 
}

/* ------------------------------------------------------------------
   🤖 Genera recetas automáticas usando la API de OpenAI (PHP backend)
   → Muestra tarjetas con recetas
   → Permite marcarlas como favoritas
   → Limpia el campo de ingredientes después de generar
------------------------------------------------------------------ */
let _last = [];
async function suggest() { 
  $("#results").innerHTML = "<p class='tag'>Generando...</p>"; 
  const r = await fetch(API_BASE + "suggest_recipes.php"); 
  const d = await r.json();

  _last = d.recetas || []; 
  if (!_last.length) { 
    $("#results").innerHTML = "<p class='tag'>Sin resultados</p>"; 
    return; 
  }

  // Mostrar recetas sugeridas
  $("#results").innerHTML = _last.map((x, i) => card(x, i)).join("");

  // Asignar evento a cada botón de "Guardar favorito"
  $("#results").querySelectorAll("[data-fav]").forEach(btn => 
    btn.addEventListener("click", async e => {
      const i = parseInt(e.currentTarget.getAttribute("data-fav")); 
      const rec = _last[i];

      await fetch(API_BASE + "favorite.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({action: "add", title: rec.titulo, data: rec})
      });

      loadFavorites();
    })
  );

  clearIngredients(); // 🧹 Limpia después de generar recetas
}

/* ------------------------------------------------------------------
   ⭐ Carga y muestra la lista de recetas favoritas guardadas
------------------------------------------------------------------ */
async function loadFavorites() { 
  const r = await fetch(API_BASE + "favorite.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({action: "list"})
  }); 
  const d = await r.json();

  $("#favorites").innerHTML = (d.items || [])
    .map(it => {
      const t = new Date(it.created_at).toLocaleString(); 
      return `<div class="fav"><b>${it.recipe_title}</b> <span class='muted'>${t}</span></div>` 
    })
    .join("") || "<p class='muted'>Sin favoritos</p>"; 
}

/* ------------------------------------------------------------------
   🕒 Carga y muestra el historial de recetas generadas
   → Se limita desde el backend (por ejemplo a 10 o 20)
------------------------------------------------------------------ */
async function loadHistory() { 
  const r = await fetch(API_BASE + "list_history.php"); 
  const d = await r.json();

  $("#history").innerHTML = (d.items || [])
    .map(it => 
      `<div class="item"><b>${it.recipe_title}</b> <span class='muted'>${new Date(it.created_at).toLocaleString()}</span></div>`
    )
    .join("") || "<p class='muted'>Sin historial</p>"; 
}

/* ------------------------------------------------------------------
   🛒 Genera una lista de compras combinando los ingredientes de las
   recetas generadas, para facilitar la preparación
------------------------------------------------------------------ */
async function genList() { 
  if (!_last.length) { 
    alert("Genera recetas primero"); 
    return; 
  } 

  const r = await fetch(API_BASE + "shopping_list.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({recipes: _last})
  }); 

  const d = await r.json(); 
  $("#shopping").innerHTML = (d.items || [])
    .map(i => `<li>${i.qty} × ${i.name}</li>`)
    .join(""); 
}

/* ------------------------------------------------------------------
   🎯 Asignar eventos a botones de la interfaz
------------------------------------------------------------------ */
$("#saveBtn").addEventListener("click", savePantry);
$("#loadBtn").addEventListener("click", loadPantry);
$("#suggestBtn").addEventListener("click", suggest);
$("#genListBtn").addEventListener("click", genList);

/* ------------------------------------------------------------------
   🚀 Cargar datos iniciales al abrir la página
------------------------------------------------------------------ */
loadPantry(); 
loadFavorites(); 
loadHistory();
