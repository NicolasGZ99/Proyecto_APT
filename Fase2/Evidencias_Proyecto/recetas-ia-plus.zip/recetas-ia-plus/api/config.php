<?php
$DB_HOST="127.0.0.1"; $DB_USER="root"; $DB_PASS=""; $DB_NAME="recetas_ia_plus";
function db(){ static $pdo=null; global $DB_HOST,$DB_USER,$DB_PASS,$DB_NAME;
  if($pdo===null){ $pdo=new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",$DB_USER,$DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
  return $pdo;
}
$OPENAI_API_KEY=getenv("OPENAI_API_KEY")?: "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";
$OPENAI_MODEL="gpt-4o-mini";
$OPENAI_URL="https://api.openai.com/v1/chat/completions";
function json_input(){ $raw=file_get_contents("php://input"); $d=json_decode($raw,true); return is_array($d)?$d:[]; }
function respond($arr,$code=200){ http_response_code($code); header("Content-Type: application/json; charset=utf-8"); echo json_encode($arr,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function normalize_ingredients($items){ $out=[]; foreach($items as $i){ $i=trim(mb_strtolower($i)); $i=preg_replace('/\s+/',' ',$i); $i=preg_replace('/\b(una|un|de|grande|mediana|pequeña|chica|gr)\b/u','',$i); $i=trim($i," ,.-"); if($i!=="" && !in_array($i,$out,true)) $out[]=$i; } return $out; }
?>