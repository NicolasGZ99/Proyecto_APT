<?php
require_once __DIR__ . "/config.php";

function normalize_receta($r) {
  $titulo = $r['titulo'] ?? $r['title'] ?? $r['name'] ?? "Sin título";
  $tiempo = $r['tiempo_min'] ?? $r['time_min'] ?? $r['tiempo'] ?? $r['time'] ?? null;
  if (is_string($tiempo) && preg_match('/(\d+)/', $tiempo, $m)) $tiempo = (int)$m[1];
  $porciones = $r['porciones'] ?? $r['servings'] ?? $r['porciones_estimadas'] ?? null;
  if (is_string($porciones) && preg_match('/(\d+)/', $porciones, $m)) $porciones = (int)$m[1];
  $ingredientes = $r['ingredientes_usados'] ?? $r['ingredientes'] ?? $r['ingredients'] ?? [];
  $pasos = $r['pasos'] ?? $r['steps'] ?? [];
  $sust = $r['sustituciones'] ?? $r['substitutions'] ?? [];
  if (!is_array($ingredientes)) $ingredientes = [];
  if (!is_array($pasos)) $pasos = [];
  if (!is_array($sust)) $sust = [];
  return [
    "titulo" => $titulo,
    "tiempo_min" => $tiempo,
    "porciones" => $porciones,
    "ingredientes_usados" => $ingredientes,
    "sustituciones" => $sust,
    "pasos" => $pasos
  ];
}

try {
  // 1) Ingredientes desde la BD
  $pdo = db();
  $rows = $pdo->query("SELECT name FROM pantry_item ORDER BY id")->fetchAll();
  $ingredients = array_map(fn($r) => $r['name'], $rows);

  // 2) Prompt: EXACTAMENTE 3 recetas en JSON (nada de texto)
  global $OPENAI_API_KEY, $OPENAI_MODEL, $OPENAI_URL;
  $system = [
    "role" => "system",
    "content" =>
      "Eres un chef profesional. Responde EXCLUSIVAMENTE en JSON válido con este esquema: " .
      "{\"recetas\":[{\"titulo\":\"string\",\"tiempo_min\":number,\"porciones\":number," .
      "\"ingredientes_usados\":[\"string\"],\"sustituciones\":[\"string\"],\"pasos\":[\"string\"]}]}. " .
      "Entrega EXACTAMENTE 3 recetas. No incluyas texto fuera del JSON. Usa solo los ingredientes disponibles."
  ];
  $user = [
    "role" => "user",
    "content" => json_encode([
      "ingredientes" => $ingredients,
      "filtros" => ["max_tiempo" => 60, "porciones" => 2]
    ], JSON_UNESCAPED_UNICODE)
  ];
  $body = [
    "model" => $OPENAI_MODEL,
    "temperature" => 0.4,               // un poco más determinista
    "messages" => [$system, $user],
    "response_format" => ["type" => "json_object"]
  ];

  // 3) Llamada a OpenAI
  $ch = curl_init($OPENAI_URL);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
      "Authorization: Bearer " . $OPENAI_API_KEY,
      "Content-Type: application/json"
    ],
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE)
  ]);
  $raw = curl_exec($ch);
  if ($raw === false) throw new Exception("cURL: " . curl_error($ch));
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($http >= 300) respond(["error" => "OpenAI HTTP $http", "raw" => $raw], 500);

  // 4) Decodificar y normalizar casos raros
  $json = json_decode($raw, true);
  $content = $json["choices"][0]["message"]["content"] ?? "{}";
  $data = json_decode($content, true);

  // Si vino texto con JSON incrustado, extraer
  if (!is_array($data) && preg_match('/\{.*\}/s', $content, $m)) {
    $data = json_decode($m[0], true);
  }

  $recetas = [];

  if (is_array($data)) {
    // Caso A: devuelve objeto con clave "recetas"
    if (isset($data["recetas"])) {
      // Si "recetas" vino como objeto único, envolverlo en arreglo
      if (is_array($data["recetas"]) && array_keys($data["recetas"]) !== range(0, count($data["recetas"])-1)) {
        $data["recetas"] = [$data["recetas"]];
      }
      foreach ((array)$data["recetas"] as $r) $recetas[] = normalize_receta($r);
    }
    // Caso B: devolvió directamente un array de recetas sin la clave "recetas"
    elseif (array_keys($data) === range(0, count($data)-1)) {
      foreach ($data as $r) $recetas[] = normalize_receta($r);
    }
  }

  // 5) Log completo para depurar
  $stmt = $pdo->prepare("INSERT INTO suggestion_log (ingredients, model, prompt, response_json) VALUES (?,?,?,?)");
  $stmt->execute([
    json_encode($ingredients, JSON_UNESCAPED_UNICODE),
    $OPENAI_MODEL,
    json_encode($body, JSON_UNESCAPED_UNICODE),
    $raw
  ]);

  // 6) Historial
  $stmt2 = $pdo->prepare("INSERT INTO recipe_history (recipe_title, data_json) VALUES (?,?)");
  foreach ($recetas as $r) {
    $stmt2->execute([$r['titulo'], json_encode($r, JSON_UNESCAPED_UNICODE)]);
  }

  respond(["recetas" => $recetas]);
} catch (Throwable $e) {
  respond(["error" => $e->getMessage()], 500);
}
