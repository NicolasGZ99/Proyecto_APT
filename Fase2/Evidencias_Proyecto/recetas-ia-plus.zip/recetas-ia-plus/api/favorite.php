<?php
require_once __DIR__."/config.php"; $in=json_input(); $action=$in['action']??'list';
try{ $pdo=db(); if($action==='add'){ $title=$in['title']??'Receta'; $data=json_encode($in['data']??[],JSON_UNESCAPED_UNICODE); $st=$pdo->prepare("INSERT INTO favorite (recipe_title,data_json) VALUES (?,?)"); $st->execute([$title,$data]); respond(["ok"=>true]); }
} catch(Throwable $e){ respond(["error"=>$e->getMessage()],500); }
