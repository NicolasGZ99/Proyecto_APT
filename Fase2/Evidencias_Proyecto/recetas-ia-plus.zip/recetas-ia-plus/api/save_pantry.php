<?php
require_once __DIR__."/config.php"; $in=json_input(); $items=normalize_ingredients($in['items']??[]);
try{ $pdo=db(); $pdo->exec("TRUNCATE TABLE pantry_item"); $st=$pdo->prepare("INSERT INTO pantry_item (name) VALUES (?)"); foreach($items as $it){ $st->execute([$it]); } respond(["ok"=>true,"count"=>count($items)]); } catch(Throwable $e){ respond(["ok"=>false,"error"=>$e->getMessage()],500); }
