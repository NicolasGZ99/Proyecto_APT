<?php
require_once __DIR__."/config.php"; try{ $rows=db()->query("SELECT id, recipe_title, data_json, created_at FROM recipe_history ORDER BY id DESC LIMIT 10")->fetchAll(); respond(["items"=>$rows]); } catch(Throwable $e){ respond(["error"=>$e->getMessage()],500); }
